"use strict";

var paths = require("./conf/gulp.conf");

// An example configuration file.
exports.config = {
    // Capabilities to be passed to the webdriver instance.
    multiCapabilities: [{
        'browserName': "chrome",
        chromeOptions: {
            args: [
                '--start-maximized'
            ]
        }
    }],

    onPrepare: function () {
        var fs = require("fs");
        var testDir = "testresults/";
        if (!fs.existsSync(testDir)) {
            fs.mkdirSync(testDir);
        }

        var jasmineReporters = require("jasmine-reporters");

        // returning the promise makes protractor wait for the reporter config before executing tests
        return browser.getProcessedConfig()
            .then(function () {
                // you could use other properties here if you want, such as platform and version

                var browserName = "browser";
                browser.getCapabilities()
                    .then(function (caps) {
                        browserName = caps.get('browserName').replace(/ /g, "_");

                        var junitReporter = new jasmineReporters.JUnitXmlReporter({
                            consolidateAll: true,
                            savePath: testDir,
                            // this will produce distinct xml files for each capability
                            filePrefix: "test-protractor-" + browserName,
                            modifySuiteName: function (generatedSuiteName) {
                                // this will produce distinct suite names for each capability,
                                // e.g. 'firefox.login tests' and 'chrome.login tests'
                                return "test-protractor-" + browserName + "." + generatedSuiteName;
                            }
                        });
                        jasmine.getEnv().addReporter(junitReporter);
                    });
            });
    },

    baseUrl: "http://localhost:3000",

    // Spec patterns are relative to the current working directory when
    // protractor is called.
    specs: [paths.e2e + "/compiled/**/*.js"],

    // Options to be passed to Jasmine-node.
    jasmineNodeOpts: {
        showColors: true,
        defaultTimeoutInterval: 30000
    }
};