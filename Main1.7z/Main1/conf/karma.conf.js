const conf = require('./gulp.conf');

module.exports = function (config) {
    const configuration = {
        basePath: '../',
        singleRun: true,
        autoWatch: false,
        browserConsoleLogOptions: {
            terminal: true,
            level: "log"
        },
        captureConsole: true,
        browserDisconnectTolerance: 3,
        failOnEmptyTestSuite: false,
        logLevel: 'error',
        browserNoActivityTimeout: 20000,
        browsers: [
            'Chrome'
        ],
        frameworks: [
            'jasmine',
            'es6-shim'
        ],
        files: [
            'node_modules/es6-shim/es6-shim.js',
            conf.path.app('index.spec.js'),
            conf.path.component('**/*.html')
        ],
        preprocessors: {
            [conf.path.app('index.spec.js')]: [
                'webpack',
                'coverage'
            ],
            [conf.path.component('**/*.html')]: [
                'ng-html2js'
            ]
        },
        ngHtml2JsPreprocessor: {
            stripPrefix: `/${conf.paths.component}/`
        },
        reporters: ['progress', 'coverage', 'junit'],
        coverageReporter: {
            reporters: [
                { type: "html", dir: "coverage/" },
                {
                    type: "cobertura",
                    dir: "testresults/",
                    subdir: ".",
                    file: "coverage-cobertura.xml"
                }
            ]
        },
        junitReporter: {
            outputDir: "testresults",
            outputFile: "test-jasmine.xml",
            suite: "",
            useBrowserName: false,
            nameFormatter: undefined,
            classNameFormatter: undefined,
            properties: {}
        },
        webpack: require('./webpack-test.conf'),
        webpackMiddleware: {
            noInfo: true,
            stats: 'errors-only'
        },
        plugins: [
            require('karma-jasmine'),
            require('karma-junit-reporter'),
            require('karma-coverage'),
            require('karma-chrome-launcher'),
            require('karma-phantomjs-launcher'),
            require('karma-phantomjs-shim'),
            require('karma-ng-html2js-preprocessor'),
            require('karma-webpack'),
            require('karma-es6-shim')
        ]
    };

    config.set(configuration);
};
