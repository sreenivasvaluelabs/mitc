const webpack = require('webpack');
const conf = require('./gulp.conf');
const path = require('path');

const HtmlWebpackPlugin = require('html-webpack-plugin');
const StyleLintPlugin = require('stylelint-webpack-plugin');
const WebpackAngularGettext = require('webpack-angular-gettext');
const autoprefixer = require('autoprefixer');

module.exports = {
    module: {
        rules: [
            {
                test: /\.json$/,
                use: [
                    'json-loader'
                ]
            },
            {
                test: /\.ts$/,
                exclude: /node_modules/,
                use: 'tslint-loader',
                enforce: 'pre'
            },
            {
                test: /\.(eot|svg|ttf|woff|woff2)$/,
                use: [
                    'url-loader'
                ]
            },
            {
                test: /\.(css|scss)$/,
                use: [
                    'style-loader',
                    'css-loader',
                    'postcss-loader',
                    'sass-loader'
                ]
            },
            {
                test: /\.ts$/,
                exclude: /node_modules/,
                use: [
                    {
                        loader: WebpackAngularGettext.loader(),
                    },
                    'ng-annotate-loader',
                    'ts-loader'
                ]
            },
            {
                test: /\.js$/,
                use: [
                    'exports-loader'
                ]
            },
            {
                test: /\.html$/,
                exclude: path.join(process.cwd(), conf.path.app()),
                use: [
                    {
                        loader: WebpackAngularGettext.loader(),
                    }
                ]
            },
            {
                test: /\.html$/,
                use: [
                    'html-loader'
                ]
            },
            {
                test: /\.po$/,
                use: [
                    {
                        loader: 'file-loader',
                        options: {
                            name: '[name].json',
                            outputPath: 'i18n/'
                        }
                    },
                    {
                        loader: 'angular-gettext-loader?format=json'
                    }
                ]
            }
        ]
    },
    plugins: [
        new StyleLintPlugin({
            configFile: '.stylelintrc.json',
            failOnError: false,
            syntax: 'scss',
            files: ['**/*.scss']
        }),
        new WebpackAngularGettext.Plugin({
            fileName: path.join(process.cwd(), conf.path.component(), 'po/strings.pot')
        }),
        new webpack.optimize.OccurrenceOrderPlugin(),
        new webpack.NoEmitOnErrorsPlugin(),
        new HtmlWebpackPlugin({
            template: conf.path.app('index.html')
        }),
        new webpack.LoaderOptionsPlugin({
            test: /\.scss$/,
            debug: true,
            options: {
                ts: {
                    configFileName: 'tsconfig.json'
                },
                tslint: {
                    configuration: require('../tslint.json')
                },
                postcss: [autoprefixer],
                sassLoader: { includePaths: [path.resolve(__dirname, '../node_modules')] }
            }
        })
    ],
    devtool: 'source-map',
    output: {
        path: path.join(process.cwd(), conf.paths.tmp),
        filename: 'index.js',
        libraryTarget: 'umd'
    },
    resolve: {
        extensions: [
            '.webpack.js',
            '.web.js',
            '.js',
            '.ts'
        ]
    },
    entry: `./${conf.path.app('index.module')}`
};