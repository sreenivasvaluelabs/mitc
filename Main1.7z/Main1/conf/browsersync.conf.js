const conf = require('./gulp.conf');

module.exports = function () {
    return {
        port:4000,
        server: {
            baseDir: [
                conf.paths.tmp,
                conf.paths.app,
                conf.paths.assets
            ]
        },
        open: false,
        notify: false
    };
};
