const webpack = require('webpack');
const conf = require('./gulp.conf');
const path = require('path');
const glob = require('glob')

const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyFilesWebpackPlugin = require('copy-webpack-plugin');
const UnminifiedWebpackPlugin = require('unminified-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');

const pkg = require('../package.json');
const autoprefixer = require('autoprefixer');
const nodeExternals = require('webpack-node-externals');

let appPath = path.join(process.cwd(), conf.path.app());

module.exports = {
    module: {
        rules: [
            {
                test: /\.json$/,
                exclude: appPath,
                use: [
                    'json-loader'
                ]
            },
            {
                test: /\.ts$/,
                exclude: [
                    /node_modules/,
                    appPath
                ],
                use: 'tslint-loader',
                enforce: 'pre'
            },
            {
                test: /\.scss$/,
                exclude: appPath,
                use: ExtractTextPlugin.extract({
                    use: ['css-loader', 'sass-loader']
                })
            },
            {
                test: /\.ts$/,
                exclude: [
                    /node_modules/,
                    appPath,
                ],
                use: [
                    'ng-annotate-loader',
                    'ts-loader'
                ]
            },
            {
                test: /\.js$/,
                exclude: appPath,
                use: [
                    'exports-loader'
                ]
            },
            {
                test: /\.html$/,
                exclude: appPath,
                use: [
                    'html-loader'
                ]
            },
            {
                test: /\.po$/,
                exclude: appPath,
                use: [
                    {
                        loader: 'file-loader',
                        options: {
                            name: '[name].js',
                            outputPath: 'i18n/'
                        }
                    },
                    {
                        loader: 'angular-gettext-loader',
                        options: {
                            module: conf.rootModuleName
                        }
                    }
                ]
            }
        ]
    },
    plugins: [
        new webpack.optimize.OccurrenceOrderPlugin(),
        new CopyFilesWebpackPlugin([
            {
                from: conf.paths.component + '/*.scss',
                to: 'index.scss'
            }
        ]),
        new webpack.NoEmitOnErrorsPlugin(),
        new webpack.optimize.UglifyJsPlugin({
            sourceMap: true,
            screwIe8: true,
            compress: { unused: true, dead_code: true, warnings: false } // eslint-disable-line camelcase
        }),
        new ExtractTextPlugin({
            filename: 'index.css'
        }),
        new UnminifiedWebpackPlugin(),
        new webpack.LoaderOptionsPlugin({
            options: {
                ts: {
                    configFileName: 'tsconfig.json'
                },
                tslint: {
                    configuration: require('../tslint.json')
                },
                sassLoader: { includePaths: [path.resolve(__dirname, '../node_modules')] }
            }
        }),
        new DtsBundlePlugin()
    ],
    output: {
        path: path.join(process.cwd(), conf.paths.dist),
        filename: 'index.min.js',
        library: conf.rootModuleName,
        libraryTarget: 'umd'
    },
    resolve: {
        extensions: [
            '.webpack.js',
            '.web.js',
            '.js',
            '.ts'
        ]
    },
    externals: [nodeExternals({
        importType: "umd",
        modulesFromFile: true
    })],
    entry: `./${conf.path.component('core.module.ts')}`
}

function DtsBundlePlugin(){}
    DtsBundlePlugin.prototype.apply = function (compiler) {
        compiler.plugin('done', function(){
            var dts = require('mi.dts-bundle');

            dts.bundle({
                name: `${conf.rootModuleName}`,
                main: `dist/src/component/**/*.d.ts`,
                out: path.join(process.cwd(), conf.paths.dist, 'index.d.ts'),
                outputAsModuleFolder: true // to use npm in-package typings
        });
    });
};