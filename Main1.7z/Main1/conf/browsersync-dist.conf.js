const conf = require('./gulp.conf');

module.exports = function () {
    return {
        server: {
            baseDir: [
                conf.paths.dist_app
            ]
        },
        open: false,
        notify: false
    };
};
