const conf = require('../conf/gulp.conf');

const path = require('path');
const gulp = require('gulp');
const shell = require('gulp-shell');
const del = require('del');

const filter = require('gulp-filter');

gulp.task('clean', clean);
gulp.task('z-build-step:other', other);
gulp.task('z-build-step:copy-npm-dependencies', copyNpmDependencies);
gulp.task('z-build-step:delete-node-modules', deleteNodeModules);
gulp.task('utilities:upgrade-all-packages', shell.task(['npm install'], { ignoreErrors: true }));
gulp.task('utilities:reinstall-all-packages', gulp.series('z-build-step:delete-node-modules', 'utilities:upgrade-all-packages'));
gulp.task('utilities:list-installed-dependencies', shell.task(['npm ls --depth=0 --prod'], { ignoreErrors: true }));
gulp.task('utilities:list-installed-dev-dependencies', shell.task(['npm ls --depth=0 --dev'], { ignoreErrors: true }));

function deleteNodeModules() {
    return del([conf.paths.node_modules]);
}

function copyNpmDependencies() {
    return gulp.src('package.json').pipe(gulp.dest(conf.paths.dist));
}

function clean() {
    // Visual Studio has a nasty habit of generating compiled JS files that cause issues. This will remove them.
    let probablyBadJs = path.join(conf.paths.src, '/**/*.{js,js.map}');
    let filesToKeep = path.join(`!${conf.paths.app}`, '{.eslintrc.js,index.spec.js}')
    return del([conf.paths.dist, conf.paths.tmp, conf.paths.dist_app, conf.paths.coverage, conf.paths.testresults, probablyBadJs, filesToKeep]);
}

function other() {
    const fileFilter = filter(file => file.stat.isFile());

    return gulp.src([
        path.join(conf.paths.src, '/**/*'),
        path.join(`!${conf.paths.src}`, '/**/*.{scss,js,html}')
    ])
    .pipe(fileFilter)
    .pipe(gulp.dest(conf.paths.dist));
}