import { DataFilter } from './data-filter-model';

export class DataFilterMap {
    Id: string;
    DataFilterId: string;
    ScoreCardId: number;
    Values: Array<string>;
    DataFilter: DataFilter;
}
