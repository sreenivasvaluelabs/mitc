import { SubjectArea } from "../common/enums";

export class CalculatedMetric {
    Participant: string;
    RankScore: string;
    MetricId: string;
    MetricName: string;
    MetricType: string;
    MetricValue: boolean;
    IsTargetMissed: boolean;
    Volume: number;
    MaskPeerNames: boolean

}
export class TeamMetric {
    Participants: string;
    RankScore: string;
    MetricId: string;
    MetricName: string;
}

export class DataRow {
    Participant: string;
    MetricValue: boolean;
    MetricName: string;
    MetricType: string;
}
export class Claim {
    Id: number;
    ClaimDate: Date;
    Vehicle: string;
    DateAnchor: string;
    KpiValue: string;
    MetricName: string;
    IsMissedTarget: boolean;
    GrossEstimateAmount:number;
    Drivable: string;
    StartDate: string;
    EndDate: string;
    SurveyId: number;
    SurveyDate: Date;
    SubjectArea:SubjectArea
}
export class MetricMeta {
    MetricName: string;
    MetricValue: string;
    MetricTime: string;
    Target: string;
    PeerAvg: string;
    CompanyAvg: string;
}

