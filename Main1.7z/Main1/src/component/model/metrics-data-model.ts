import { SubjectArea, AnchorType } from "../common/enums";

export class MetricsDataModel {
    public KpiList: Array<Metric>;
    public SelectedMetrics: Array<ScoreCardMetricMap>;
}

export class ScoreCardMetricMap {
    public Target?: number;
    public Weight?: number;
    public MetricId: number;
    public MetricName: string;
    public SubArea: SubjectArea;
    public DateAnchorId: number;
    public HierarchyAnchorId: number;
    public OwnershipAnchorId: number;
    public ScoreThisMetric: boolean;
    public DateAnchor: Anchor;
    public HierarchyAnchor: Anchor;
    public OwnershipAnchor: Anchor;
}

export class Metric {
    Id: number;
    Name: string;
    SubjectArea: SubjectArea;
    MitchellRecommended: boolean;
    IsHeigherBetter: boolean;
}

export class Anchor {
    Id: number;
    Type: AnchorType;
    Name: string;
    SubjectArea: SubjectArea;
    Default: boolean;
}
