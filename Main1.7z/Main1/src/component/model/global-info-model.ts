import { HierarchyType, ParticipantType, ScoreCardLevel } from '.././common/enums';
import { Array } from 'es6-shim';

export class GlobalInfoModel {
    public scoreCardId: string;
    public copiedScoreCardId: string;
}

export class Region {
    public Key: number;
    public Name: string;
    public Code?: string;
    public Level?: number;
    public Status?: boolean;
}

export class Division {
    public Key: number;
    public Name: string;
    public Code?: string;
    public Level?: number;
    public Status?: boolean;
}

export class Office {
    public Key: number;
    public Name: string;
    public Code?: string;
    public Level?: number;
    public Status?: boolean;
}

export class Resource {
    public Key: number;
    public Name: string;
    public Level?: number;
    public Code?: string;
    public Status?: boolean;
    public IsExists?: boolean;//required for disabling checkboxes
}

export class CustomGroup {
    public Name: string;
    public Resources: Array<Resource> = new Array();
}

export class Hierarchy {
    public GroupName?: string;
    public RegionKey?: number;
    public DivisionKey?: number;
    public OfficeKey?: number;
    public ParticipantKey?: number;
}

