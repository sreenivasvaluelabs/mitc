import * as angular from 'angular';
export interface ICommonService {
    generateGUID();
    getGUID_List(list: Array<any>, column: string);
}
export class CommonService implements ICommonService {

    public generateGUID(): string {
        function s4() {
            return Math.floor((1 + Math.random()) * 0x10000)
                .toString(16)
                .substring(1);
        }
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
            s4() + '-' + s4() + s4() + s4();
    }

    public getGUID_List(list: Array<any>, column: string): Array<any> {
        let that = this;
        angular.forEach(list, function (value: any, key: any) {
            list[key][column] = that.generateGUID();
        });
        return list;
    }
}

