import { BaseContoller } from '../common/base-controller';
import { ICommonEventsService, CommonEventsService } from '../service/common-events-service';
import _ from "lodash";
import { IVisualizationDataService, VisualizationDataService } from '../service/aggregate-calculation-service';
import { Subject } from 'rxjs/Subject';
import { CalculatedMetric, DataRow } from "../model/aggregate-calculation-model";
import 'angular-ui-grid';
import { ScoreCardDataService } from '../service/scorecard-data-service';
import { ScoreCard } from '../model/scorecard-model';
import { TimeFrame } from '../model/time-frame-model';
import { SelectDuration } from '../common/enums';

export class RegionViewInfoController {
    //Arrays to get the Teams,Peers and Summary Data
    public summaryList: Array<CalculatedMetric> = [];
    public teamsList: Array<CalculatedMetric> = [];
    public peersList: Array<CalculatedMetric> = [];
    //variables set for ui grid
    public gridOptions: any;
    public gridApi: any;
    public tempfinalArray: any[] = [];//for data
    public fieldsData: Array<any> = [];//for columns
    //variables for tabs identifying
    public Tabsvalue: any;
    public PerrValue: any;
    //Variable for target Off Check
    public offTargetCheck: any;
    //variable to display the dynamic region
    public region: any;
    public scoreCardId:any;
    //Temporary arrays for loops
    public tempData: any[] = [];
    public tabsData: any[] = [];
    public peerData: any[] = [];

    public targetCount: number;
    public gridRightScroll : boolean = true;
    //Data Needs to be integrated from scorecard view page.
    public userkey: number = 1;
    public scoreCardlevel: any = 1;
    public scoreCardTimeFrame: string = "4";


    public currentScoreCard: ScoreCard;
    //Code for loading dropdowns
    public selectDuration: string[] = [SelectDuration[0], SelectDuration[1], SelectDuration[2]];
    public selectRange: string[] = [];
    public selectTimeFrame: string;
    public selectedRange: string;

    public linelabels: string[] = ["January", "February", "March", "April", "May", "June"];
    public linedata: any = [65, 59, 80, 81, 56, 55];

    public popuplinelabels: string[] = ["January", "February", "March", "April", "May", "June"];
    public popuplinedata: any = [65, 59, 80, 81, 56, 55];

    public lineoptions: any = {
        maintainAspectRatio:false,
        tooltips: {
            callbacks: {
                label: function (tooltipItem, data) {
                    return data['datasets'][0]['data'][tooltipItem['index']] + '%';
                }
            },
            backgroundColor: 'rgba(13,174,218,1)',
            titleFontSize: 0,
            bodyFontColor: '#fff',
            bodyFontSize: 14,
            displayColors: false
           
        },
        elements: {
            line: {
                tension: 0,
                fill: false,
                backgroundColor: '#0daeda',
                borderColor: '#0daeda',
                borderWidth:2.5
            },
            point: {
                pointStyle: 'circle',
                radius: 3,
                hoverRadius: 3,
                borderColor:'rgba(13, 174, 218,1)',
                backgroundColor:'rgba(13, 174, 218,1)', 
                hoverBackgroundColor: 'rgba(13, 174, 218,1)',
                borderWidth:8             
            }
        },
        scales: {
            xAxes: [{
                gridLines: {
                  display: false,
                  drawBorder: false,
                  color:'#dfdede'
                },
                ticks: {
                  fontSize: 14,
                  fontColor: '#302e2c',
                  fontFamily: "Open Sans"
                }
              }],
              yAxes: [{
                gridLines: {
                  drawBorder: false,
                  color:'#dfdede'
                },
                ticks: {
                  beginAtZero: true,
                  fontSize: 14,
                  fontColor: '#302e2c',
                  min: 0,
                  max: 100,
                  stepSize: 25,
                  padding: 25,
                  fontFamily: "Open Sans"
                }
              }]
           
        }
    };
    
    public linecolors: any = [{
        pointBackgroundColor: 'rgba(13, 174, 218,1)',
        pointHoverBackgroundColor: 'rgba(13, 174, 218,1)'
    }];

    public pielabels: any = ["Score", "No Score"];
    public piedata: any = [90, 10];
    public pieoptions: any = {
        cutoutPercentage: 87,
        maintainAspectRatio:false
    };
    public piecolors: any = ["#4fa806", "#9b9b9b"];
    
    public $stateobj:ng.ui.IStateService;

    public changedRange() {
        if (this.selectedRange === 'Year To Date' || this.selectedRange === 'Prev 12 months'
            || this.selectedRange === 'Prev 6 months' || this.selectedRange === 'Prev Year') {
            this.selectDuration = [SelectDuration[0], SelectDuration[1]];
        }
        else if (this.selectedRange === 'Quarter To Date' || this.selectedRange === 'Prev 3 months'
            || this.selectedRange === 'Quarter 1, Prev Year' || this.selectedRange === 'Quarter 2, Prev Year'
            || this.selectedRange === 'Quarter 3, Prev Year' || this.selectedRange === 'Quarter 4, Prev Year'
            || this.selectedRange === 'Quarter 1, Current Year' || this.selectedRange === 'Quarter 2, Current Year'
            || this.selectedRange === 'Quarter 3, Current Year') {
            this.selectDuration = [SelectDuration[1], SelectDuration[2]];
        }
        else if (this.selectedRange === 'Month To Date' || this.selectedRange === 'Prev 30 days' || this.selectedRange === 'Prev  month') {
            this.selectDuration = [SelectDuration[2]];
        }
        this.selectTimeFrame = this.selectDuration[0];
        this.changedSubRange();
    }
    public changedSubRange() {
          var array:any[]=this.visualizationDataService.getGraphData(this.scoreCardId,this.selectedRange, this.selectTimeFrame) 
          console.log(array);
          debugger;
          this.linelabels=array[0];
          this.linedata=array[1];
    }



    constructor(private visualizationDataService: VisualizationDataService, private scorecardDataService: ScoreCardDataService, private commonEventsService: ICommonEventsService, private $state: ng.ui.IStateService, $stateParams) {
        
        this.$stateobj = $state;
        
        this.getScoreCardData($stateParams.scoreid);
        this.scoreCardId=$stateParams.scoreid;
        //SummaryData
        let scoreCardLevel = 1;
        this.getSummaryData(this.userkey);
        //TabsData
        this.getTeamsData(this.userkey, this.scoreCardlevel, this.scoreCardTimeFrame);
        //PeersData
        this.getPeersData(this.userkey, this.scoreCardlevel, this.scoreCardTimeFrame);

        var vm = this;

        vm.gridApi = null;
        this.region = $stateParams.regionname;
        this.Tabsvalue = true;
        this.PerrValue = false;
        

        vm.gridOptions = {
            columnDefs: this.fieldsData,
            data: this.tempfinalArray,
            enableColumnMenus: false,
            enableColumnResizing: true,
            enableFiltering: true,
            showTreeExpandNoChildren: true,
            enableVerticalScrollbar: true,
            enableHorizontalScrollbar: true,
            enableSelectAll: false,
            exporterMenuPdf: true,
            exporterCsvFilename: 'UserList.csv',
            enableGridMenu: false,
            exporterMenuCsv: false,
            onRegisterApi: (gridApi) => {
                this.gridApi = gridApi;
                this.gridApi.grid.registerDataChangeCallback(() => {
                    this.gridApi.treeBase.expandAllRows();
                });
            }
        };
        vm.gridOptions.appScopeProvider = this;
        this.gridOptions.onRegisterApi = function (gridApi) {
            vm.gridApi = gridApi;
        }
    };


    //to define the column definition call this function
    public getColumnDefs(aggregatedData: Array<CalculatedMetric>): Array<any> {
        this.gridOptions.columnDefs = [];
        this.gridOptions.data = [];
        this.fieldsData = [];

        this.fieldsData.push({
            name: 'Participants',
            field: 'Participant',
            headerTooltip: true,
            cellTooltip: true,
            pinnedLeft: true,
            cellClass: function (grid) {
                let isPeerSelected = grid.appScope.checkIsPeer();
                if (isPeerSelected) {
                    return 'ui-grid-cell-contents position:absolute mi-color-brand-05 mi-grid-link  noborder'
                } else {
                    return 'boldText ui-grid-cell-contents position:absolute noborder'
                }
            },
            cellTemplate: '<div ng-click="grid.appScope.participantsClick(COL_FIELD);">{{COL_FIELD}}</div>',
            width: 190,
        });


        this.fieldsData.push({
            name: 'Rank/Score',
            field: 'RankScore',
            headerTooltip: true,
            cellTooltip: true,
            pinnedLeft: true,
            width: 100,
            sort: { direction: 'asc' }
        });
        for (let data of <Array<any>>aggregatedData) {
            for (let item of <Array<any>>data) {
                this.fieldsData.push({
                    name: item['MetricName'],
                    field: this.getFieldName(item['MetricName']),
                    headerTooltip: true,
                    cellTooltip: true,
                    //minWidth: 150,
                    width: 250,
                    headerCellClass: "mi-align-center",
                    cellTemplate: '<div class="ui-grid-cell-contents mi-align-center" ng-click="grid.appScope.showGridPopup(COL_FIELD, $event)">{{COL_FIELD}}</div>',
                    cellClass: function (this, grid, row, col, value, rowRenderIndex, colRenderIndex) {

                        let rowIndex = grid.renderContainers.body.renderedRows.indexOf(row);
                        let participantName = grid.renderContainers.body.renderedRows[rowIndex].entity.Participant;


                        let isMissedTarget = grid.appScope.checkTarget(grid.renderContainers.body.renderedRows.indexOf(row), this.displayName, participantName);
                        if (isMissedTarget) {
                            return 'mi-color-hi-alert noborder'
                        } else {
                            return 'noborder'
                        }
                    }
                });
            }
        }
        console.log(this.fieldsData);
        return this.fieldsData;
    };


    //Binding TimeFrames Dropdowns
    public getScoreCardData(scorecardid) {
        this.scorecardDataService.getScoreCard(scorecardid).then(scoreData => {
            
            if (<ScoreCard>scoreData) {
                this.currentScoreCard = <ScoreCard>scoreData;
                for (let timeframe of <Array<TimeFrame>>this.currentScoreCard.TimeFrames) {
                    this.selectRange.push(timeframe.Name);
                }
                this.selectedRange = this.selectRange[0];
                this.changedRange();
            }
        });
    };

    public showGridPopup(value, event) {
        $('.kpi-info-popup').css({ 'left': event.screenX - 20, 'top': event.screenY - 420, 'display': 'block' })
    }

    // private cellCalss(grid: any, row: any, col: any, rowRenderIndex: any, colRenderIndex: any) { optimization by vijay
    //     // var obj = <>
    // }

    //to disable the link on peer tab
    public checkIsPeer() {
        if (!this.PerrValue)
            return true;
        else
            return false;

    }

    //to check if target is missed for the metric call this function
    public checkTarget(row, metricName, participantName) {
        if (!this.PerrValue) {
            for (let obj in this.tempData) {
                //alert(obj);
                let filteredMetrics = this.tempData[obj].find(x => x.MetricName == metricName && x.Participant == participantName)
                if (filteredMetrics != undefined) {
                    return filteredMetrics.IsTargetMissed;
                }
            }
            return false;
        }
        else {
            return false;
        }
    }

    //To remove spaces from column names call this method
    public getFieldName(fieldName: string): string {
        let field = '';
        if (fieldName) {
            field = fieldName.replace('%', '');
        }
        return field ? field.replace(/ /g, '') : '';
    };

    //To get summary data from service
    public getSummaryData(key) {
        this.visualizationDataService.getSummaryData(key).then(summaryData => {
            if (<Array<CalculatedMetric>>summaryData) {
                this.summaryList = [];
                this.summaryList = <Array<CalculatedMetric>>summaryData;
            }
        });
    };

    //To get TeamsData from servce
    public getTeamsData(userKey, scoreCardLevel, scoreCardTimeFrame) {
        this.tabsData = [];
        this.visualizationDataService.getTeamsData(userKey, scoreCardLevel, scoreCardTimeFrame).then(teamData => {
            if (<Array<CalculatedMetric>>teamData) {
                this.teamsList = <Array<CalculatedMetric>>teamData;
                this.getTeamData();
            }
        });
    };

    //To get PeersData from servce
    public getPeersData(userKey, scoreCardLevel, scoreCardTimeFrame) {
        this.peerData = [];
        this.visualizationDataService.getPeersData(userKey, scoreCardLevel, scoreCardTimeFrame).then(peersData => {
            if (<Array<CalculatedMetric>>peersData) {
                this.peersList = <Array<CalculatedMetric>>peersData;
                this.getPeerData();

            }
        });
    };

    //method called when teams tab is clicked and then column def are defined and  data is loaded
    public getTeamData() {
        this.offTargetCheck = false;
        this.tabsData = this.fillData(this.teamsList);
        this.getColumnDefs(this.teamsList);
        this.gridOptions.columnDefs = this.fieldsData;
        this.gridOptions.data = this.tabsData;
    }

    //method called when peers tab is clicked  then column def are defined and  data is loaded
    public getPeerData() {
        this.offTargetCheck = false;
        if (this.PerrValue) {
            this.peerData = this.fillData(this.peersList);
            this.getColumnDefs(this.peersList);
            this.gridOptions.columnDefs = this.fieldsData;
            this.gridOptions.data = this.peerData;
        }
    }

    //To get the data into array which is  assigned to data array of grid
    public fillData(aggregatedData: Array<CalculatedMetric>) {
        // optimization by vijay
        // let dataRowMap: Map<string, Array<DataRow>> = new Map<string, Array<DataRow>>();
        // aggregatedData.forEach((cm) => {
        //     let found:boolean = false;
        //     dataRowMap.forEach((v, k)=>{
        //         if(k === cm.Participant){
        //             found = true;
        //         }
        //     });
        //     if(found){

        //     }
        //     dataRow.push(cm);
        //     dataRowMap[cm.Participant] = dataRow;
        // });
        // let dataRows:Array<DataRow> = new Array();
        // dataRowMap.forEach((v) =>{
        //     dataRows = dataRows.concat(v);
        // })

        this.tempData = [];
        if (!this.PerrValue) {
            this.tempData = aggregatedData;
        }
        this.targetCount = 0;
        let targetMissedSCorecard: boolean = false;
        this.tempfinalArray = [];
        let participantName: number = 1;
        for (let data of <Array<any>>aggregatedData) {
            let dataObj = {};
            if (data[0]["MaskPeerNames"] && this.PerrValue) {
                dataObj["Participant"] = "Participant" + participantName;
                participantName = participantName + 1;
            }
            else {
                dataObj["Participant"] = data[0]["Participant"];
            }

            dataObj["RankScore"] = data[0]["RankScore"];


            for (let item of <Array<any>>data) {
                let fieldName = this.getFieldName(item['MetricName']);
                if (item['MetricType'] != '$') {
                    dataObj[fieldName] = item['MetricValue'] + item['MetricType'];
                    //to get the target count
                    if (item['IsTargetMissed']) { targetMissedSCorecard = true }
                }
                else {
                    dataObj[fieldName] = item['MetricType'] + item['MetricValue'];
                    if (item['IsTargetMissed']) { targetMissedSCorecard = true }


                }

            }
            if (targetMissedSCorecard)
                this.targetCount = this.targetCount + 1;

            this.tempfinalArray.push(dataObj);
        }
        return this.tempfinalArray;

    };

    //paricipant Column click
    public participantsClick(value) {

        let tempVal = /shop/gi;
        if (value.search(tempVal) < 0 && !this.PerrValue) {
            this.offTargetCheck = false;
            let Val = /County/gi;
            if (value.search(Val) < 0) {
                this.userkey = 1;
                this.scoreCardlevel = 1
                
                this.getSummaryData(this.userkey);
                this.getTeamsData(this.userkey, this.scoreCardlevel, this.scoreCardTimeFrame);
                this.getPeersData(this.userkey, this.scoreCardlevel, this.scoreCardTimeFrame);

                this.region = value;

            }
            else {
                this.userkey = 2;
                this.scoreCardlevel = 2
                
                this.getSummaryData(this.userkey);
                this.getTeamsData(this.userkey, this.scoreCardlevel, this.scoreCardTimeFrame);
                this.getPeersData(this.userkey, this.scoreCardlevel, this.scoreCardTimeFrame);

                this.region = value;

            }
            this.Tabsvalue = true;
            this.PerrValue = false;
        }
        else { 
            this.$stateobj.go('shopview'); 
        }
    };

    //button to get only the target missed columns
    public offTargetChecked() {
        if (this.offTargetCheck) {
            this.gridOptions.data = [];
            this.tempfinalArray = [];
            let missedTargetMetrics: Array<string> = [];
            for (let data of <Array<any>>this.teamsList) {
                for (let i = 0; i < data.length; i++) {
                    if (data[i].IsTargetMissed == true && missedTargetMetrics.indexOf(data[i].MetricName) === -1) {
                        missedTargetMetrics.push(data[i].MetricName);
                    }
                }
            }
            for (let data of <Array<any>>this.teamsList) {
                let dataObj = {};
                dataObj["Participant"] = data[0]["Participant"];
                dataObj["RankScore"] = data[0]["RankScore"];
                for (let i = 0; i < data.length; i++) {
                    if (missedTargetMetrics.indexOf(data[i].MetricName) != -1) {
                        let fieldName = this.getFieldName(data[i]['MetricName']);
                        if (data[i]['MetricType'] != '$') {
                            dataObj[fieldName] = data[i]['MetricValue'] + ' ' + data[i]['MetricType'];
                        }
                        else {
                            dataObj[fieldName] = data[i]['MetricType'] + ' ' + data[i]['MetricValue'];
                        }
                        //dataObj[fieldName] = data[i]['MetricValue'];
                    }
                }
                this.tempfinalArray.push(dataObj);
            }
            this.fieldsData = [];
            this.fieldsData.push({
                name: 'Participants',
                field: 'Participant',
                headerTooltip: true,
                cellTooltip: true,
                pinnedLeft: true,
                cellClass: function (grid) {
                    let isPeerSelected = grid.appScope.checkIsPeer();
                    if (isPeerSelected) {
                        return 'ui-grid-cell-contents position:absolute mi-color-brand-05 mi-grid-link  noborder'
                    } else {
                        return 'boldText ui-grid-cell-contents position:absolute noborder'
                    }
                },
                width: 190
            });
            this.fieldsData.push({
                name: 'Rank/Score',
                field: 'RankScore',
                headerTooltip: true,
                cellTooltip: true,
                pinnedLeft: true,
                width: 100
            });
            for (let data of <Array<any>>this.teamsList) {
                for (let i = 0; i < data.length; i++) {
                    if (missedTargetMetrics.indexOf(data[i].MetricName) != -1) {
                        this.fieldsData.push({
                            name: data[i]['MetricName'],
                            field: this.getFieldName(data[i]['MetricName']),
                            headerTooltip: true,
                            cellTooltip: true,
                            headerCellClass: "mi-align-center",
                            cellClass: function (this, grid, row, col, value, rowRenderIndex, colRenderIndex) {
                                let rowIndex = grid.renderContainers.body.renderedRows.indexOf(row);
                                let participantName = grid.renderContainers.body.renderedRows[rowIndex].entity.Participant;


                                let retval = grid.appScope.checkTarget(grid.renderContainers.body.renderedRows.indexOf(row), this.displayName, participantName);
                                if (retval) {
                                    return 'mi-color-hi-alert noborder'
                                } else {
                                    return 'noborder'
                                }
                            }
                        });
                    }
                }
            }
            this.gridOptions.columnDefs = [];
            this.gridOptions.columnDefs = this.fieldsData;
            this.gridOptions.data = this.tempfinalArray;
            
        }
        else {
            this.gridOptions.columnDefs = [];
            this.gridOptions.data = [];
            this.getTeamsData(this.userkey, this.scoreCardlevel, this.scoreCardTimeFrame);
            this.getPeersData(this.userkey, this.scoreCardlevel, this.scoreCardTimeFrame);
            

        }

    };

};


export const RegionView: angular.IComponentOptions = {
    template: require('./aggregate-calculation.html'),
    controller: RegionViewInfoController
};












