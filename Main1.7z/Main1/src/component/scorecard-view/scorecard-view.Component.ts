import { ScoreCardDataService } from '../service/scorecard-data-service';
import { ScoreCard } from '../model/scorecard-model';

export class ScoreCardViewInfoController {
public TempList:any[]=[];
public top:any[];
public bottom:any[];
public MainList:any[]=[];
public loopVariable:any=0;
public scoreCardArray:any[]=[];

    constructor(private $state: ng.ui.IStateService, private scorecardDataService: ScoreCardDataService) {
        //IF API is used to return data then the top and bottom are to be assigned here
        this.top=[{tops:'Fender Bender'},{tops:'Convoy Auto'},{tops:'Mira Mesa Auto'},{tops:'Franklin Auto'},{tops:'5th Street Glass Repair'}];
        this.bottom=[{bottoms:'La Jolla Auto'},{bottoms:'UTC Auto Body'},{bottoms:'Balboa Auto Shop'},{bottoms:'North Park Auto'},{bottoms:'Mira Mesa Auto'}];

       
       
       //for loop to display top and bottom performers of different levels of scorecards
        for (let entry of this.top) {
        this.TempList=[];
        this.TempList.push(entry.tops);
        this.TempList.push(this.bottom[this.loopVariable].bottoms)
        this.MainList.push(this.TempList);
        this.loopVariable++;
        }
         this.getAllScorecards();
        //static Data
        //  this.scoreCardArray=[{regionName:'Texas Region Scorecard',value:this.MainList},
        //                       {regionName:'East County Scorecard',value:this.MainList},
        //                       {regionName:'San Diego Scorecard',value:this.MainList}
        //                       ];

      
       



                   
  }
  // getting all the scorecards
  public getAllScorecards()
  {
       this.scorecardDataService.getScoreCards().then(scoreData => {
        console.log(scoreData);
          debugger;
           this.scoreCardArray = <Array<ScoreCard>>scoreData;
            
            //Adding to top and bottom 5 performersas static data.remove this and get the dynamic data 
            this.scoreCardArray.forEach(obj=>
        {
            obj.value=this.MainList;

        });
           console.log(this.scoreCardArray);
        });

  };

     
}


export const ScoreCardView: angular.IComponentOptions = {
    template: require('./scorecard-view.html'),
    controller: ScoreCardViewInfoController
};
