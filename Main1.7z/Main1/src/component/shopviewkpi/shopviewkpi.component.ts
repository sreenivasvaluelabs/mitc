import { BaseContoller } from '../common/base-controller';
import _ from "lodash";
import { Subject } from 'rxjs/Subject';
import { IVisualizationDataService, VisualizationDataService } from '../service/aggregate-calculation-service';
import { Claim } from "../model/aggregate-calculation-model";
import 'angular-ui-grid';
import { SubjectArea } from "../common/enums";
import { getClaimColumns } from "../common/utilities";


export class ShopViewKPIInfoController {
    public tempfinalArray: any;
    public fieldsData: Array<any> = [];//for columns
    public claimsList: Array<Claim>;
    public gridOptions: any;
    public gridApi: any;
    public missedTarget: boolean;
    public metricName: string;
    public subjectArea: SubjectArea;

    constructor(private $state: ng.ui.IStateService, $stateParams, private visualizationDataService: VisualizationDataService) {
        debugger;
        let userKey = 2;
        let metricId = 41
        let timeFrameId = 1;
        let vm = this;
        vm.gridApi = null;
        vm.gridOptions = {
            columnDefs: this.fieldsData,
            data: this.tempfinalArray,
            enableColumnMenus: false,
            enableColumnResizing: true,
            enableFiltering: true,
            showTreeExpandNoChildren: true,
            enableVerticalScrollbar: true,
            enableHorizontalScrollbar: true,
            enableSelectAll: false,
            exporterMenuPdf: true,
            exporterCsvFilename: 'UserList.csv',
            enableGridMenu: false,
            exporterMenuCsv: false,
            onRegisterApi: (gridApi) => {
                this.gridApi = gridApi;
                this.gridApi.grid.registerDataChangeCallback(() => {
                    this.gridApi.treeBase.expandAllRows();
                });
            }
        };
        vm.gridOptions.appScopeProvider = this;
        this.gridOptions.onRegisterApi = function (gridApi) {
            vm.gridApi = gridApi;
        }

        this.visualizationDataService.getMetricClaims(userKey, metricId, timeFrameId).then(claimsData => {
            if (<Array<Claim>>claimsData) {
                this.claimsList = [];
                this.claimsList = <Array<Claim>>claimsData;
                let metricObject = this.claimsList.find(m => m.IsMissedTarget == true);
                this.missedTarget = metricObject.IsMissedTarget;
                this.metricName = metricObject.MetricName;
                this.subjectArea = metricObject.SubjectArea;
                let claimColumns = getClaimColumns(this.subjectArea)
                this.getColumnsdata(claimColumns);
                this.gridOptions.columnDefs = this.fieldsData;
                this.gridOptions.data = this.claimsList;
                this.claimsList.length
            }
        });
    };

    public getcellClass(column: string) {
        switch (column) {
            case 'Id':
                return 'mi-color-brand-05 noborder mi-grid-link';
            case 'KpiValue':
                return 'ui-grid-cell-contents noborder mi-color-hi-alert';
        }
        return 'ui-grid-cell-contents noborder';

    }

    public getColumnsdata(claimColumns: any) {
        this.gridOptions.columnDefs = [];
        this.gridOptions.data = [];
        this.fieldsData = [];
        debugger;
        for (let k in claimColumns[0]) {
            this.fieldsData.push({
                name: claimColumns[0][k],
                field: k,
                headerTooltip: true,
                cellTooltip: true,
                pinnedLeft: true,
                cellClass: this.getcellClass(k),
                cellTemplate: '<div ng-click="grid.appScope.participantsClick(COL_FIELD);">{{COL_FIELD}}</div>',
                minWidth: 150

            });
        }



        // this.fieldsData.push({
        //     name: 'Claim',
        //     field: 'Id',
        //     headerTooltip: true,
        //     cellTooltip: true,
        //     pinnedLeft: true,
        //     cellClass: 'boldText ui-grid-cell-contents position:absolute noborder',
        //     cellTemplate: '<div ng-click="grid.appScope.participantsClick(COL_FIELD);">{{COL_FIELD}}</div>',
        //     width: 190,
        // });
        // this.fieldsData.push({
        //     name: 'Date',
        //     field: 'ClaimDate',
        //     headerTooltip: true,
        //     cellTooltip: true,
        //     pinnedLeft: true,
        //     cellClass: 'ui-grid-cell-contents position:absolute noborder',
        //     width: 190,
        // });
        // this.fieldsData.push({
        //     name: 'Owner',
        //     field: 'Owner',
        //     headerTooltip: true,
        //     cellTooltip: true,
        //     pinnedLeft: true,
        //     cellClass: 'ui-grid-cell-contents position:absolute noborder',
        //     width: 190,
        // });
        // this.fieldsData.push({
        //     name: 'Vehicle',
        //     field: 'Vehicle',
        //     headerTooltip: true,
        //     cellTooltip: true,
        //     pinnedLeft: true,
        //     cellClass: 'ui-grid-cell-contents position:absolute noborder',
        //     width: 190,
        // });
        // if (this.missedTarget) {
        //     this.fieldsData.push({
        //         name: 'KPI Value',
        //         field: 'KpiValue',
        //         headerTooltip: true,
        //         cellTooltip: true,
        //         pinnedLeft: true,
        //         cellClass: 'mi-color-hi-alert',
        //         width: 190,
        //     });
        // }
        // else {
        //     this.fieldsData.push({
        //         name: 'KPI Value',
        //         field: 'KpiValue',
        //         headerTooltip: true,
        //         cellTooltip: true,
        //         pinnedLeft: true,
        //         //cellClass: 'noborder',
        //         width: 190,
        //     });
        // }
        debugger;

    }
};
export const ShopViewKPI: angular.IComponentOptions = {
    template: require('./shopviewkpi.html'),
    controller: ShopViewKPIInfoController
};












