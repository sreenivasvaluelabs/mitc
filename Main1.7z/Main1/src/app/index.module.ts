import * as angular from 'angular';
import * as angularMaterial from 'angular-material';
import * as angularGettext from 'angular-gettext';
import 'angular-ui-router';
import 'angular-ui-grid/ui-grid.css';
import 'angular-material/angular-material.css';
import './components/miEnvironment';
import componentModule from '../component/core.module';
import './localizations';
import './index.scss';
import 'mi.ux-uifonts/style.scss';
import 'flag-icon-css/sass/_flag-icon.scss';


angular
    .module('app',
    [
        'ui.router', 'miEnvironment', 'gettext', componentModule, angularMaterial
    ])
    