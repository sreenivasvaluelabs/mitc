module.exports = {
  extends: [
    'angular'
  ],
  rules: {
    'angular/no-service-method': 0
  }
}
