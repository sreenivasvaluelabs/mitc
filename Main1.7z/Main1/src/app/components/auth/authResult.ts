export class AuthResult {
    constructor(public data: string, public status: number) {

    }
}
