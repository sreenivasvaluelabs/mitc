import { AuthResult } from './authResult';
import { AuthenticationHandler } from './authenticationHandler';

export class AuthenticationInterceptor implements ng.IHttpInterceptor {
    static Factory($q: ng.IQService, $injector: ng.auto.IInjectorService, authenticationHandler: AuthenticationHandler): AuthenticationInterceptor {
        return new AuthenticationInterceptor($q, $injector, authenticationHandler);
    }

    /** @ngInject */
    constructor(private $q: ng.IQService, private $injector: ng.auto.IInjectorService, private authenticationHandler: AuthenticationHandler) {
    }

    // Define response error as method that takes a response parameter which is a callback, and
    // returns a promise itself.
    responseError = (response: ng.IHttpPromiseCallbackArg<{}>): ng.IPromise<{}> => {
        // If we aren't authenticated
        if (response.status === 401) {
            let $http = this.$injector.get('$http');

            // Try to authenticate again
            return this.authenticationHandler
                .authenticate()
                .then(() => {
                    // If we did manage to authenticate try the original request
                    // that failed again.
                    if (response.config) {
                        return $http(response.config);
                    }
                });
        }

        let deferred = this.$q.defer();
        deferred.reject(response);

        return deferred.promise;
    }
}
