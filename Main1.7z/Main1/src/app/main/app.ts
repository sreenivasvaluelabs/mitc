import { AuthenticationHandler } from '../components/auth/authenticationHandler';
import 'angular-gettext';

class AppController {
    isAuthenticated: boolean = false;
    doShowComponent: boolean = false;
    version: string;
    moduleName: string;
    moduleDescription: string;
    currentLanguage: string = 'en-us';
    generatorName: string = 'generator-mi-webpack-angularjs-component';

    private mdSidenav: ng.material.ISidenavObject;

    /** @ngInject */
    constructor(private $mdSidenav: ng.material.ISidenavService, private gettextCatalog: ng.gettext.gettextCatalog, private authenticationHandler: AuthenticationHandler) {
        // Ugly, but does correctly get the data we need. Webpack will take care of extracting these details out
        // for dist publishing.
    }

  
}

export const App: angular.IComponentOptions = {
    template: require('./App.html'),
    controller: AppController
};
