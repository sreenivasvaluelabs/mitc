const path = require('path');
const webpack = require('webpack');

module.exports = {
    module: {
        rules: [
            {
                test: /\.ts$/,
                exclude: /node_modules/,
                use: 'tslint-loader',
                enforce: 'pre'
            },
            {
                test: /\.(css|scss|po|json)$/,
                use: [
                    'ignore-loader',
                ]
            },
            {
                test: /\.ts$/,
                exclude: /node_modules/,
                use: [
                    'ng-annotate-loader',
                    'ts-loader'
                ]
            },
            {
                test: /\.html$/,
                use: [
                    'html-loader'
                ]
            }
        ]
    },
    plugins: [
        new webpack.LoaderOptionsPlugin({
            options: {
                resolve: {},
                ts: {
                    configFileName: 'tsconfig.json'
                },
                tslint: {
                    configuration: require('../tslint.json')
                }
            },
            debug: true
        })
    ],
    devtool: 'source-map',
    node: {
        fs: 'empty'
    },
    resolve: {
        extensions: [
            '.webpack.js',
            '.web.js',
            '.js',
            '.ts'
        ]
    }
};
