const webpack = require('webpack');
const conf = require('./gulp.conf');
const path = require('path');

const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const pkg = require('../package.json');

function diff(source, alter) {
    return source.filter(function (i) { return alter.indexOf(i) < 0; });
};

module.exports = {
    module: {
        loaders: [
            {
                test: /.json$/,
                loaders: [
                    'json-loader'
                ]
            },
            {
                test: /\.ts$/,
                exclude: /node_modules/,
                use: 'tslint-loader',
                enforce: 'pre'
            },
            {
                test: /\.(eot|svg|ttf|woff|woff2)$/,
                use: [
                    'url-loader'
                ]
            },
            {
                test: /\.(css|scss)$/,
                use: [
                    'style-loader',
                    'css-loader',
                    'postcss-loader',
                    'sass-loader'
                ]
            },
            {
                test: /\.ts$/,
                exclude: /node_modules/,
                use: [
                    'ng-annotate-loader',
                    'ts-loader'
                ]
            },
            {
                test: /\.js$/,
                use: [
                    'exports-loader'
                ]
            },
            {
                test: /\.html$/,
                use: [
                    'html-loader'
                ]
            },
            {
                test: /\.po$/,
                use: [
                    {
                        loader: 'file-loader',
                        options: {
                            name: '[name].json',
                            outputPath: 'i18n/'
                        }
                    },
                    {
                        loader: 'angular-gettext-loader',
                        options: {
                            format: 'json'
                        }
                    }
                ]
            }
        ]
    },
    plugins: [
        new webpack.optimize.OccurrenceOrderPlugin(),
        new webpack.NoEmitOnErrorsPlugin(),
        new HtmlWebpackPlugin({
            template: conf.path.app('index.html')
        }),
        new webpack.optimize.UglifyJsPlugin({
            sourceMap: true,
            screwIe8: true,
            mangle: false,
            compress: { unused: true, dead_code: true, warnings: false } // eslint-disable-line camelcase
        }),
        new ExtractTextPlugin('index-[contenthash].css'),
        new webpack.optimize.CommonsChunkPlugin({ names: ['vendor'] }),
        new webpack.LoaderOptionsPlugin({
            options: {
                ts: {
                    configFileName: 'tsconfig.json'
                },
                tslint: {
                    configuration: require('../tslint.json')
                },
                sassLoader: { includePaths: [path.resolve(__dirname, '../node_modules')] }
            }
        })
    ],
    output: {
        path: path.join(process.cwd(), conf.paths.dist_app),
        filename: '[name]-[hash].js',
        chunkFilename: '[name].js',
        libraryTarget: 'umd'
    },
    resolve: {
        extensions: [
            '.webpack.js',
            '.web.js',
            '.js',
            '.ts'
        ]
    },
    entry: {
        app: `./${conf.path.app('index.module.ts')}`,
        vendor: diff(Object.keys(pkg.dependencies), ['mi.ux-uifonts', 'mi.ux-uistyles'])
    }
};