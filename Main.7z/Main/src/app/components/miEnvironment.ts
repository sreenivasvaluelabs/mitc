import * as angular from 'angular';
import { EnvironmentCollection } from 'mi.estimating';

export class MiEnvironment implements EnvironmentCollection {
    public services: Map<string, string>;

    constructor() {
        this.services = new Map<string, string>();
        this.services['partsSelection'] = 'https://estimate-dev.mymitchell.com/PartsSelectionService/';
        this.services['authentication'] = 'https://repaircenter-dev.mymitchell.com/OAuth2Server/1.0/OAuth/Token';
        this.services['partPriceApi'] = 'https://estimate-dev.mymitchell.com/PartPriceApi/';
        this.services['estimateDocument'] = 'https://estimate-dev.mymitchell.com/EstimateDocumentApi/v1';
    }

    static get Default() {
        return new MiEnvironment();
    }
}

angular
    .module('miEnvironment', [])
    .constant('miEnvironment', MiEnvironment.Default);
