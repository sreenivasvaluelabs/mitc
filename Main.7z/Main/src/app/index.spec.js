const context = require.context('../component', true, /\.(js|ts|tsx)$/);
context.keys().forEach(context);
