import { AuthenticationInterceptor } from './components/auth/authenticationInterceptor';

/** @ngInject */
function interceptorConfig($httpProvider: ng.IHttpProvider) {
    /* push the factory function to the array of $httpProvider
     * interceptors (implements IHttpInterceptorFactory) */
    $httpProvider.interceptors.push(AuthenticationInterceptor.Factory);
};

export default interceptorConfig;
