const appContext = require.context('../app', true, /\.(po)$/);
appContext.keys().forEach(appContext);

const componentContext = require.context('../component', true, /\.(po)$/);
componentContext.keys().forEach(componentContext);
