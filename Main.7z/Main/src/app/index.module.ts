import * as angular from 'angular';
import * as angularMaterial from 'angular-material';
import * as angularGettext from 'angular-gettext';
import 'angular-ui-router';

import 'angular-material/angular-material.css';

import './components/miEnvironment';

import { AuthenticationHandler } from './components/auth/authenticationHandler';
import { App } from './main/app';

import routesConfig from './routes';
import interceptorConfig from './interceptors';
import componentModule from '../component/core.module';

import './localizations';
import './index.scss';
/*import './miUX-UIFonts/style.scss';*/

angular
    .module('app',
    [
        'ui.router', 'miEnvironment', 'gettext', componentModule, angularMaterial
    ])
    .service('authenticationHandler', AuthenticationHandler)
    .config(routesConfig)
    .config(interceptorConfig)
    .component('app', App);
