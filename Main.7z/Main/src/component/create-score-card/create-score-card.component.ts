import { Stage } from '../service/navigation-stage-service';

export class CreateScoreCardController {
    private currentPage: Stage;

    constructor(private $state: ng.ui.IStateService) {
        this.currentPage = Stage.GlobalInfo;
    }

    public $onInit() {
        let currentStage = this.$state.params.stage;
        if (currentStage) {
            this.updateCurrentPage(<Stage>currentStage);
        }
    }

    public isCurrentPage(name: string) {
        if (Stage[this.currentPage] === name) {
            return true;
        } else {
            return false;
        }
    }
     private updateCurrentPage(stage: Stage) {
        this.currentPage = stage;
    }
}
export const CreateScoreCard: angular.IComponentOptions = {
    template: require('./create-score-card.html'),
    controller: CreateScoreCardController
};