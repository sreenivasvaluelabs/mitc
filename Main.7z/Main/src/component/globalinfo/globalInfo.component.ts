import { Participant } from '../model/participant-model';
import { BaseContoller } from '../common/base-controller';
import { ICommonEventsService, CommonEventsService } from '../service/common-events-service';
import { IGlobalInfoDataService, GlobalInfoDataService } from '../service/globalinfo-data-service';
import { IApiDataService, ApiDataService } from '../service/api-data-service';
import { CustomGroup, Hierarchy, Division, GlobalInfoModel, Office, Region, Resource } from '../model/global-info-model';
import { HierarchyType, ParticipantType, ScoreCardLevel } from '.././common/enums';
import * as angular from 'angular';
import { IScoreCardDataService, ScoreCardDataService } from '../service/scorecard-data-service';
import { ScoreCard } from '../model/scorecard-model';
import { TimeFrame } from '../model/time-frame-model';
import { isNullOrUndefined } from 'util';
import { isThisTypeNode, ArrayBindingElement } from 'typescript';
import { Array } from 'es6-shim';
import { arraysAreEqual } from 'tslint/lib/utils';

export class GlobalInfoController extends BaseContoller {

    public scoreCard: ScoreCard;
    public timeFrames: Array<TimeFrame>;
    public timeFrameGroups: Array<Array<TimeFrame>>;
    public existingScoreCards: Array<ScoreCard>;
    public participants: Array<any>;

    public regions: Array<Region> = new Array();
    public selectedRegion: any;

    public divisions: Array<Division> = new Array();
    public selectedDivision: any;

    public offices: Array<Office> = new Array();
    public selectedOffice: any;

    public states: Array<Division> = new Array();
    public counties: Array<Office> = new Array();

    public resources: Array<Resource> = new Array();
    public selectedResources: Array<Resource> = new Array();

    public customGroups: Array<CustomGroup> = new Array();
    public selectedGroup: any;

    public rbtnStandard: boolean = true;
    public rbtnCustom: boolean = true;
    public isRequired: boolean = false;
    public selectedScoreCard: string;

    public modalCopyScorecard: boolean = false;
    public modalCopyTemplate: boolean = false;
    public modalCustomizeStdHierarcy: boolean = false;
    public modalCustomizeScorecardviewers: boolean = false;
    public modalCustomHierarcy: boolean = false;
    public modalErrorMessage: boolean = false;
    public showApplyButton: boolean = true;
    public scoreCardNameExists: boolean = false;
    public errorMessage: string = '';

    public hierarchyType = HierarchyType;
    public userLevels = ScoreCardLevel;

    public searchResource: string = '';
    public isResourceReq: boolean;
    public isAllResources: boolean;
    public btnSaveEnable: boolean = true;
    public loopUpType: boolean = true;
    public copyOfTree: Array<Participant> = new Array();
    public copiedCustomGroups: Array<CustomGroup> = new Array();

    ////-----------------Who canView Properties---------------------//////
    public whoCanViewTree: Array<Participant> = new Array();

    ////-----------------Who canView Properties End----------------//////

    ////-----------------Standard Heirarcy Properties---------------------//////
    public stdHierarchyTree: Array<Participant> = new Array();
    public selectedStdHeirarcy: Array<Hierarchy> = new Array();

    ////-----------------Standard Heirarcy Properties End----------------//////


    constructor(private globalInfoDataService: IGlobalInfoDataService,
        private commonEventsService: ICommonEventsService, private $state: ng.ui.IStateService, private scorecardDataService: IScoreCardDataService) {
        super();

        this.modalCustomHierarcy = false;
        this.participants = this.globalInfoDataService.getParticipants();
        this.commonEventsService.getEvent('save').takeUntil(this.$destroy).subscribe(() => {
            this.save();
        });
        if (!this.scorecardDataService.getCurrentScoreCard() && !this.scorecardDataService.getCurrentScoreCardId()) {
            this.scoreCard = new ScoreCard();
            this.globalInfoDataService.getTimeFrames().then(trimeframes => {
                this.loadTimeFrames(<Map<number, Array<TimeFrame>>>trimeframes);
            });
        } else {
            this.edit();
        }
    }

    public edit() {
        this.scoreCard = this.scorecardDataService.getCurrentScoreCard();
        this.scoreCard.DefaultTimeFrameId = this.scoreCard.DefaultTimeFrameId.toString();
        this.globalInfoDataService.getTimeFrames().then(trimeframes => {
            this.loadTimeFrames(<Map<number, Array<TimeFrame>>>trimeframes);
            this.selectParticipantType(this.scoreCard.ParticipantType);
        });
        if (this.scoreCard.HierarchyType === this.hierarchyType.Custom && this.scoreCard.Hierarchy.length > 0) {
            this.customHierarcyEdit();
        }

    }

    public customHierarcyEdit() {
        this.globalInfoDataService.getCustomGroupResources(this.scoreCard.Id).then(res => {
            for (let hmap of this.scoreCard.Hierarchy) {
                let resources = <Array<Resource>>res;
                let group = this.customGroups.find(x => x.Name === hmap.GroupName);
                let list = resources.filter(x => x.Key === hmap.ParticipantKey);
                if (!group) {
                    let resource = {
                        Name: hmap.GroupName,
                        Resources: list
                    }
                    this.customGroups.push(resource);
                } else {
                    group.Resources = group.Resources.concat(list);
                }
            }
        });
    }

    public copyScoreCard(scorecardId: number) {
        this.scorecardDataService.getScoreCard(scorecardId).then(sc => {
            if (sc) {
                this.scorecardDataService.setIsCloningOrCopying(sc.Id);
                this.scoreCard = sc;
                this.scoreCard.Id = -1;
                this.selectParticipantType(this.scoreCard.ParticipantType);
                this.scoreCard.DefaultTimeFrameId = this.scoreCard.DefaultTimeFrameId.toString();
            }
        });
    }

    public copyExistingScorecard() {
        this.modalCopyScorecard = true;
        this.scorecardDataService.getScoreCards().then(data => {
            if (<Array<ScoreCard>>data) {
                this.existingScoreCards = <Array<ScoreCard>>data;
            }
        });
    };

    public onChangeParticipantType(participant: number) {
        this.clearTreesData();
        this.selectParticipantType(participant);
        this.scoreCard.ParticipantType = participant;
    }

    public selectParticipantType(participant: number) {
        switch (participant) {
            case ParticipantType.NetworkShops:
                this.rbtnStandard = false;
                this.rbtnCustom = false;
                break;
            case ParticipantType.OutOfNetWorkShops:
                this.rbtnStandard = false;
                this.rbtnCustom = false;
                break;
            case ParticipantType.Staff:
                this.rbtnStandard = false;
                this.rbtnCustom = true;
                if (this.scoreCard.HierarchyType === this.hierarchyType.Custom) {
                    this.scoreCard.HierarchyType = this.hierarchyType.Standard;
                }
                break;
            case ParticipantType.IA:
                this.rbtnStandard = false;
                this.rbtnCustom = true;
                if (this.scoreCard.HierarchyType === this.hierarchyType.Custom) {
                    this.scoreCard.HierarchyType = this.hierarchyType.Standard;
                }
                break;
        }
        if (this.scoreCard.HierarchyType === undefined) {
            this.scoreCard.HierarchyType = this.hierarchyType.Standard;
        }

    }

    public clearTreesData() {
        this.stdHierarchyTree.splice(0, this.stdHierarchyTree.length);
        this.selectedStdHeirarcy.splice(0, this.selectedStdHeirarcy.length);
        this.scoreCard.Hierarchy.splice(0, this.scoreCard.Hierarchy.length);

        this.divisions.splice(0, this.divisions.length);
        this.offices.splice(0, this.offices.length);
        this.resources.splice(0, this.resources.length);
        this.selectedRegion = '';
        this.selectedDivision = '';
        this.selectedOffice = '';
        this.selectedResources.splice(0, this.selectedResources.length);
        this.selectedGroup = undefined;
        this.customGroups.splice(0, this.customGroups.length);

        this.whoCanViewTree.splice(0, this.whoCanViewTree.length);
        this.scoreCard.ScoreCardVisibilityMaps.splice(0, this.scoreCard.ScoreCardVisibilityMaps.length);
    }

    public selectTimeFrames(timeframe: TimeFrame) {
        let idx = this.scoreCard.TimeFrames.findIndex(t => t.Id === timeframe.Id);
        if (idx >= 0) {
            timeframe.isChecked = false;
            this.scoreCard.TimeFrames.splice(idx, 1);
            if (this.scoreCard.DefaultTimeFrameId === timeframe.Id.toString()) {
                this.scoreCard.DefaultTimeFrameId = '';
            }
        } else {
            timeframe.isChecked = true;
            if (this.scoreCard.TimeFrames.length < 6) {
                this.scoreCard.TimeFrames.push(timeframe);
            } else {
                this.modalErrorMessage = true;
                this.errorMessage = 'No of selected timeframes exceeds 6';
                timeframe.isChecked = false;
            }
        }
    }

    public timeFrameChecked(timeframe: TimeFrame): boolean {
        if (this.scoreCard.TimeFrames) {
            let tf = this.scoreCard.TimeFrames.find(t => t.Id === timeframe.Id);
            if (tf) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public timeFrameCheckedCalss(timeframe: TimeFrame): string {
        if (this.timeFrameChecked(timeframe)) {
            return 'checked';
        } else {
            return 'unChecked';
        }
    }

    public isPeerformanceChecked() {
        if (!this.scoreCard.DisplayPeerPerformance) {
            this.scoreCard.MaskPeerNames = false;
        }
    }

    public rbtnUserLevelClick(level: number) {
        this.scoreCard.Level = level;
    }

    public rbtnHierarcyTypeClick(hierarcyType: number) {
        this.clearTreesData();
        this.scoreCard.HierarchyType = hierarcyType;
        if (this.scoreCard.HierarchyType === this.hierarchyType.Custom && this.scoreCard.Level !== this.userLevels.Resource && this.scoreCard.Level !== this.userLevels.Office) {
            this.scoreCard.Level = undefined;
        } else {
            this.loadStdHierarchyTree();
        }
    }

    public onChangeWhoCanView(val: boolean) {
        if (val) {
            this.whoCanViewTree.splice(0, this.whoCanViewTree.length);
            this.scoreCard.ScoreCardVisibilityMaps.splice(0, this.scoreCard.ScoreCardVisibilityMaps.length);
        } else {
            this.loadWhoCanViewTree();
        }
    }

    public update(selectedScoreCard: number) {
        if (selectedScoreCard) {
            this.showApplyButton = false;
        } else {
            this.showApplyButton = true;
        }
    }

    public closeDialog() {
        this.modalCopyScorecard = false;
        this.modalCopyTemplate = false;
        this.modalErrorMessage = false;
        this.errorMessage = '';
    }

    public closeStdHierarchyModal() {
        this.modalCustomizeStdHierarcy = false;
        this.stdHierarchyTree = angular.copy(this.copyOfTree);
        this.copyOfTree.splice(0, this.copyOfTree.length);
    }

    public closeCustomHierarchyModal() {
        this.modalCustomHierarcy = false;
        this.customGroups = angular.copy(this.copiedCustomGroups);
        this.copyOfTree.splice(0, this.copyOfTree.length);
    }

    public closeWhoCanViewModal() {
        this.modalCustomizeScorecardviewers = false;
        this.whoCanViewTree = angular.copy(this.copyOfTree);
        this.copyOfTree.splice(0, this.copyOfTree.length);
    }

    public btnApplyScorecard(selectedScoreCard: number) {
        this.copyScoreCard(selectedScoreCard);
        this.modalCopyScorecard = false;
    }

    ////------Create Custom Hierarcy-------////
    public createCustomHierary() {
        this.modalCustomHierarcy = true;
        this.globalInfoDataService.getAllRegions().then(regions => {
            if (<Array<Region>>regions) {
                this.regions = <Array<Region>>regions;
            }
            this.divisions.splice(0, this.divisions.length);
            this.offices.splice(0, this.offices.length);
            this.resources.splice(0, this.resources.length);
            this.selectedRegion = '';
            this.selectedDivision = '';
            this.selectedOffice = '';
            this.selectedResources.splice(0, this.selectedResources.length);
        });

        if (this.customGroups.length > 0) {
            this.copiedCustomGroups = angular.copy(this.customGroups);
        }
    }

    public onChangeRegion() {
        if (this.selectedRegion) {
            this.globalInfoDataService.getDivisionsByRegionId(this.selectedRegion).then(divisions => {
                if (<Array<Division>>divisions) {
                    this.divisions = <Array<Division>>divisions;
                }
            });
        }
        this.divisions.splice(0, this.divisions.length);
        this.offices.splice(0, this.offices.length);
        this.resources.splice(0, this.resources.length);
        this.selectedDivision = '';
        this.selectedOffice = '';
        this.selectedResources.splice(0, this.selectedResources.length);
        this.selectedGroup = undefined;
    }

    public onChangeDivision() {
        if (this.selectedDivision) {
            this.globalInfoDataService.getOfficesByDivisionId(this.selectedDivision).then(offices => {
                if (<Array<Office>>offices) {
                    this.offices = <Array<Office>>offices;
                }
            });
        }
        this.offices.splice(0, this.offices.length);
        this.resources.splice(0, this.resources.length);
        this.selectedOffice = '';
        this.selectedResources.splice(0, this.selectedResources.length);
        this.selectedGroup = undefined;
    }

    public onChangeOffice() {
        if (this.selectedOffice) {
            this.globalInfoDataService.getResourcesByOfficeId(this.selectedOffice, this.scoreCard.ParticipantType).then(resources => {
                if (this.customGroups && this.customGroups.length > 0) {
                    this.disableResources(resources);
                } else {
                    if (<Array<Resource>>resources) {
                        this.resources = <Array<Resource>>resources;
                    }
                }
            });
        }
        this.resources.splice(0, this.resources.length);
        this.selectedResources.splice(0, this.selectedResources.length);
        this.selectedGroup = undefined;
    }

    public onChangeLookUpType(val: boolean) {
        this.states = this.divisions;
        this.counties = this.offices;
        this.selectedGroup = undefined;
        this.selectedResources.splice(0, this.selectedResources.length);
        this.resources.splice(0, this.resources.length);
        this.customGroups.splice(0, this.customGroups.length);
    }

    public selectResources(resource: Resource) {
        let idx = this.selectedResources.findIndex(t => t.Key === resource.Key);
        if (idx >= 0) {
            this.selectedResources.splice(idx, 1);
        } else {
            this.selectedResources.push(resource);
        }
    }

    public onChangeAddToGroup() {
        this.isResourceReq = false;
        if (this.selectedResources.length > 0) {
            if (this.selectedGroup === 'Add') {
                this.customGroups.push({
                    Name: '',
                    Resources: angular.copy(this.selectedResources)
                });
                this.btnSaveEnable = true;
            } else {
                let idx = this.customGroups.findIndex(t => t.Name === this.selectedGroup);
                if (idx >= 0) {
                    for (let res of <Array<any>>this.selectedResources) {
                        this.customGroups[idx].Resources.push(res);
                    }
                }
            }
            this.selectedResources.splice(0, this.selectedResources.length);
            this.disableResources(this.resources);
            this.isAllResources = false;
        } else {
            this.isResourceReq = true;
        }
        this.selectedGroup = undefined;
    }

    public deleteCustomGroup(Key: number) {
        if (Key >= 0) {
            this.customGroups.splice(Key, 1);
            this.disableResources(this.resources);
        }
    }

    public removeResource(Key: number) {
        for (let item of <Array<any>>this.customGroups) {
            let idx = item.Resources.findIndex(t => t.Key === Key);
            if (idx >= 0) {
                item.Resources.splice(idx, 1);
                if (item.Resources.length === 0) {
                    let dx = this.customGroups.indexOf(item);
                    this.customGroups.splice(dx, 1);
                }
                this.disableResources(this.resources);
            }
        }
    }

    public resourceChecked(resource: any) {
        let chkd = false;
        if (this.selectedResources) {
            for (let i = 0; i < this.selectedResources.length; i++) {
                let t = this.selectedResources[i];
                if (resource.Name === t.Name) {
                    chkd = true;
                    break;
                } else {
                    chkd = false;
                }
            }
        }
        return chkd;
    }

    public disableResources(data: any) {
        this.resources = new Array();
        let objData = new Array();
        for (let objGroup of <Array<any>>this.customGroups) {
            for (let obj of <Array<any>>objGroup.Resources) {
                objData.push(obj);
            }
        }

        for (let item of <Array<any>>data) {
            let isExist = objData.some(res => {
                return res.Key === item.Key;
            });
            if (isExist) {
                item.IsExists = true;
            } else {
                item.IsExists = false;
            }
        }

        if (isNullOrUndefined(this.customGroups)) {
            data.map(x => x.IsExists = false);
        }

        this.resources = data;
    }

    public selectAllResource() {
        if (this.isAllResources) {
            for (let obj of <Array<any>>this.resources) {
                if (!obj.IsExists) {
                    this.selectedResources.push(obj);
                }
            }
        } else {
            for (let obj of <Array<any>>this.resources) {
                let idx = this.selectedResources.findIndex(t => t.Key === obj.Key);
                if (idx >= 0 && !obj.IsExists) {
                    this.selectedResources.splice(idx, 1);
                }
            }
        }
    }

    public checkGroupName(idx: number, gname: string) {
        if (gname && this.customGroups.length > 1) {
            let duplicateList = angular.copy(this.customGroups);
            duplicateList.splice(idx, 1);
            if (duplicateList.length > 0) {
                let isNameExisting = duplicateList.find(x => x.Name === gname);
                if (isNameExisting) {
                    this.customGroups[idx].Name = '';
                    alert(' group name already exists');
                }
            }
        }

        let emptyName = this.customGroups.some(x => x.Name === '');
        if (!emptyName) {
            this.btnSaveEnable = false;
        } else {
            this.btnSaveEnable = true;
        }
    }

    public saveCustomHierarcy() {
        this.scoreCard.Hierarchy = new Array<Hierarchy>();
        for (let group of this.customGroups) {
            for (let res of group.Resources) {
                this.scoreCard.Hierarchy.push({
                    GroupName: group['Name'],
                    ParticipantKey: res['Key']
                });
            }
            this.modalCustomHierarcy = false;
        }
    }
    ////------Create Custom Hierarcy End-------////


    ////-----------------Who canView---------------------//////

    public customizeStandardHierarcy() {
        this.modalCustomizeStdHierarcy = true;
        if (this.stdHierarchyTree.length > 0) {
            this.copyOfTree = angular.copy(this.stdHierarchyTree);
        } else {
            this.loadStdHierarchyTree();
        }
    }

    public customizeScorecardViewers() {
        this.modalCustomizeScorecardviewers = true;
        if (this.whoCanViewTree.length === 0) {
            this.loadWhoCanViewTree();
        } else {
            this.copyOfTree = angular.copy(this.whoCanViewTree);
        }
    }

    public loadStdHierarchyTree() {
        if (this.stdHierarchyTree.length === 0) {
            this.globalInfoDataService.getAllRegions().then(region => {
                if (!isNullOrUndefined(region)) {
                    this.stdHierarchyTree = <Array<Participant>>region;
                    this.stdHierarchyTree.map(obj => obj.Status = true);
                    if (this.scorecardDataService.getCurrentScoreCardId() || this.scorecardDataService.getIsCloningOrCopying()) {
                        this.setStdTree(this.stdHierarchyTree, 'RegionKey');
                    }
                }
            });
        }
    }

    public loadWhoCanViewTree() {
        if (this.whoCanViewTree.length === 0) {
            this.globalInfoDataService.getAllRegions().then(region => {
                if (<Array<Region>>region) {
                    this.whoCanViewTree = <Array<Participant>>region;
                    if (this.scorecardDataService.getCurrentScoreCardId() || this.scorecardDataService.getIsCloningOrCopying()) {
                        this.setViewTree(this.whoCanViewTree, 'RegionKey');
                    } else {
                        if (this.scoreCard.HierarchyType === this.hierarchyType.Standard) {
                            if (this.scoreCard.Level <= 1) {
                                this.selectRegionsFromStdHierarchy(this.whoCanViewTree);
                            }
                        }
                    }
                }
            });
        }
    }

    public selectRegionsFromStdHierarchy(participants: Array<Participant>) {
        let participantsList = participants;
        participantsList.forEach(obj => {
            let val = this.stdHierarchyTree.find(x => x.Key === obj.Key);
            if (val.Status) {
                obj.Status = true;
            }
        });
    }

    public setCheckedRegion(region: Participant) {
        region.Status = !region.Status;
        if (!isNullOrUndefined(region.Children)) {
            region.Children.forEach(div => {
                div.Status = region.Status;
                if (!isNullOrUndefined(div.Children)) {
                    div.Children.forEach(ofc => {
                        ofc.Status = region.Status;
                        if (!isNullOrUndefined(ofc.Children)) {
                            ofc.Children.forEach(resource => {
                                resource.Status = region.Status;
                            });
                        }
                    });
                }
            });
        }
    }

    public setCheckedDivision(region: Participant, div: Participant) {
        div.Status = !div.Status;
        if (!isNullOrUndefined(div.Children)) {
            div.Children.forEach(ofc => {
                ofc.Status = div.Status;
                if (!isNullOrUndefined(ofc.Children)) {
                    ofc.Children.forEach(resource => {
                        resource.Status = div.Status;
                    });
                }
            });
        }
        region.Status = region.Children.some(obj => !obj.Status) ? false : true;
    }

    public setCheckedOffice(region: Participant, division: Participant, office: Participant) {
        office.Status = !office.Status;
        if (!isNullOrUndefined(office.Children)) {
            office.Children.forEach(resource => {
                resource.Status = office.Status;
            });
        }
        division.Status = division.Children.some(obj => !obj.Status) ? false : true;
        region.Status = region.Children.some(obj => !obj.Status) ? false : true;
    }

    public setCheckedResource(region: Participant, division: Participant, office: Participant, resource: Participant) {
        resource.Status = !resource.Status;
        office.Status = office.Children.some(obj => !obj.Status) ? false : true;
        division.Status = division.Children.some(obj => !obj.Status) ? false : true;
        region.Status = region.Children.some(obj => !obj.Status) ? false : true;
    }

    public saveWhoCanView() {
        this.scoreCard.ScoreCardVisibilityMaps = new Array<Hierarchy>();
        this.prepareWhoCanViewData(this.whoCanViewTree);
        this.modalCustomizeScorecardviewers = false;
        this.copyOfTree.splice(0, this.copyOfTree.length);
    }

    public prepareWhoCanViewData(participants: Array<Participant>) {
        participants.forEach(obj => {
            let selectedViewers;
            if (obj.Status) {
                selectedViewers = new Hierarchy();
                selectedViewers.RegionKey = obj.Level === 1 ? obj.Key : null;
                selectedViewers.DivisionKey = obj.Level === 2 ? obj.Key : null;
                selectedViewers.OfficeKey = obj.Level === 3 ? obj.Key : null;
                selectedViewers.ParticipantKey = obj.Level === 4 ? obj.Key : null;
            }
            if (selectedViewers) {
                this.scoreCard.ScoreCardVisibilityMaps.push(selectedViewers);
            }
        });
        participants.forEach(obj => {
            if (!obj.Status && obj.Children && obj.Children.length > 0) {
                this.prepareWhoCanViewData(obj.Children);
            }
        });
    }

    public saveStdHeirarcy() {
        this.scoreCard.Hierarchy = new Array<Hierarchy>();
        this.prepareStdHeirarcyData(this.stdHierarchyTree);
        this.selectedStdHeirarcyData(this.stdHierarchyTree);
        this.modalCustomizeStdHierarcy = false;
        this.copyOfTree.splice(0, this.copyOfTree.length);
    }

    public prepareStdHeirarcyData(participants: Array<Participant>) {
        let data = new Array<Hierarchy>();
        for (let reg of participants) {
            if (!reg.Status) {
                if (reg.Children) {
                    for (let div of reg.Children) {
                        if (!div.Status) {
                            if (div.Children) {
                                for (let ofc of div.Children) {
                                    if (!ofc.Status) {
                                        if (ofc.Children) {
                                            for (let res of ofc.Children) {
                                                if (!res.Status) {
                                                    let obj = new Hierarchy();
                                                    obj.RegionKey = reg.Key;
                                                    obj.DivisionKey = div.Key;
                                                    obj.OfficeKey = ofc.Key;
                                                    obj.ParticipantKey = res.Key;
                                                    data.push(obj);
                                                }
                                            }
                                        } else {
                                            let obj = new Hierarchy();
                                            obj.RegionKey = reg.Key;
                                            obj.DivisionKey = div.Key;
                                            obj.OfficeKey = ofc.Key;
                                            data.push(obj);
                                        }
                                    }
                                }
                            } else {
                                let obj = new Hierarchy();
                                obj.RegionKey = reg.Key;
                                obj.DivisionKey = div.Key;
                                data.push(obj);
                            }
                        }
                    }
                } else {
                    let obj = new Hierarchy();
                    obj.RegionKey = reg.Key;
                    data.push(obj);
                }
            }
        }
        this.scoreCard.Hierarchy = data;
    }

    public selectedStdHeirarcyData(participants: Array<Participant>) {
        participants.forEach(obj => {
            let selectedHierarchy;
            if (obj.Status) {
                selectedHierarchy = new Hierarchy();
                selectedHierarchy.RegionKey = obj.Level === 1 ? obj.Key : null;
                selectedHierarchy.DivisionKey = obj.Level === 2 ? obj.Key : null;
                selectedHierarchy.OfficeKey = obj.Level === 3 ? obj.Key : null;
                selectedHierarchy.ParticipantKey = obj.Level === 4 ? obj.Key : null;
            }
            if (selectedHierarchy) {
                this.selectedStdHeirarcy.push(selectedHierarchy);
            }
        });
        participants.forEach(obj => {
            if (!obj.Status && obj.Children && obj.Children.length > 0) {
                this.selectedStdHeirarcyData(obj.Children);
            }
        });
    }

    public setStdTree(participantsList: Array<Participant>, filterKey: string) {
        participantsList.map(obj => obj.Status = true);
        if (this.scoreCard.Hierarchy) {
            this.scoreCard.Hierarchy.forEach(obj => {
                if (!isNullOrUndefined(obj[filterKey])) {
                    let pickedParticipant = participantsList.find(reg => {
                        return reg.Key === obj[filterKey];
                    });
                    if (!isNullOrUndefined(pickedParticipant)) {
                        pickedParticipant.Status = false;
                    }
                }
            });
        }
    }

    public setStdTreeData(selectedPrticipant: Participant, filterKey: string) {
        if (selectedPrticipant.Status === true) {
            selectedPrticipant.Children.map(obj => {
                obj.Status = true;
            });
        } else {
            let isParentExist: boolean;
            this.scoreCard.Hierarchy.forEach(obj => {
                let hasParentKey = obj.RegionKey === selectedPrticipant.Key || obj.DivisionKey === selectedPrticipant.Key || obj.OfficeKey === selectedPrticipant.Key;
                if (hasParentKey && !obj[filterKey]) {
                    isParentExist = true;
                }
            });
            if (isParentExist || selectedPrticipant['IsParentExist']) {
                selectedPrticipant.Children.map(obj => {
                    obj.Status = false;
                    obj['IsParentExist'] = true;
                });
            } else {
                this.setStdTree(selectedPrticipant.Children, filterKey);
            }
        }
    }

    public setViewTree(participantsList: Array<Participant>, filterKey: string) {
        let data = this.scoreCard.ScoreCardVisibilityMaps;
        if (data) {
            data.forEach(obj => {
                if (!isNullOrUndefined(obj[filterKey])) {
                    let pickedParticipant = participantsList.find(reg => {
                        return reg.Key === obj[filterKey];
                    });
                    if (!isNullOrUndefined(pickedParticipant)) {
                        pickedParticipant.Status = true;
                    }
                }
            });
        }
    }

    public setViewTreeData(selectedPrticipant: Participant, filterKey: string) {
        if (selectedPrticipant.Status === true) {
            selectedPrticipant.Children.map(obj => {
                obj.Status = true;
            });
        } else {
            this.setViewTree(selectedPrticipant.Children, filterKey);
        }
    }

    public getStdParticipantsByKey(selectedParticipant: Participant) {
        if (isNullOrUndefined(selectedParticipant.Children)) {
            switch (selectedParticipant.Level) {
                case 1:
                    this.globalInfoDataService.getDivisionsByRegionId(selectedParticipant.Key).then(childs => {
                        if (!isNullOrUndefined(childs)) {
                            selectedParticipant.Children = childs as Array<Participant>;
                            this.setStdTreeData(selectedParticipant, 'DivisionKey');
                        }
                    });
                    break;
                case 2:
                    this.globalInfoDataService.getOfficesByDivisionId(selectedParticipant.Key).then(childs => {
                        if (!isNullOrUndefined(childs)) {
                            selectedParticipant.Children = childs as Array<Participant>;
                            this.setStdTreeData(selectedParticipant, 'OfficeKey');
                        }
                    });
                    break;
                case 3:
                    this.globalInfoDataService.getResourcesByOfficeId(selectedParticipant.Key, this.scoreCard.ParticipantType).then(childs => {
                        if (!isNullOrUndefined(childs)) {
                            selectedParticipant.Children = childs as Array<Participant>;
                            this.setStdTreeData(selectedParticipant, 'ParticipantKey');
                        }
                    });
                    break;
            }
        }
    }

    public getViewParticipantsByKey(selectedParticipant: Participant) {
        let data = this.scoreCard.Id > 0 ? this.scoreCard.ScoreCardVisibilityMaps : this.selectedStdHeirarcy;
        if (isNullOrUndefined(selectedParticipant.Children)) {
            switch (selectedParticipant.Level) {
                case 1:
                    this.globalInfoDataService.getDivisionsByRegionId(selectedParticipant.Key).then(childs => {
                        if (!isNullOrUndefined(childs)) {
                            selectedParticipant.Children = childs as Array<Participant>;
                            if (data && selectedParticipant.Children) {
                                for (let item of <Array<any>>selectedParticipant.Children) {
                                    let child = data.find(x => x.DivisionKey === item.Key);
                                    if (this.scoreCard.HierarchyType === this.hierarchyType.Standard && child) {
                                        item.Status = true;
                                    }
                                }
                            }
                            if (this.scoreCard.Level < 2) {
                                this.setViewTreeData(selectedParticipant, 'DivisionKey');
                            }
                        }
                    });
                    break;
                case 2:
                    this.globalInfoDataService.getOfficesByDivisionId(selectedParticipant.Key).then(childs => {
                        if (!isNullOrUndefined(childs)) {
                            selectedParticipant.Children = childs as Array<Participant>;

                            if (data && selectedParticipant.Children) {
                                for (let item of <Array<any>>selectedParticipant.Children) {
                                    let child = data.find(x => x.OfficeKey === item.Key);

                                    if (this.scoreCard.HierarchyType === this.hierarchyType.Standard && child) {
                                        item.Status = true;
                                    }
                                }
                            }
                            if (this.scoreCard.Level < 3) {
                                this.setViewTreeData(selectedParticipant, 'OfficeKey');
                            }
                        }
                    });
                    break;
                case 3:
                    this.globalInfoDataService.getResourcesByOfficeId(selectedParticipant.Key, undefined).then(childs => {
                        if (!isNullOrUndefined(childs)) {
                            selectedParticipant.Children = childs as Array<Participant>;
                            if (data && selectedParticipant.Children) {
                                for (let item of <Array<any>>selectedParticipant.Children) {
                                    let child = this.scoreCard.HierarchyType === this.hierarchyType.Custom ? this.scoreCard.Hierarchy.find(x => x.ParticipantKey === item.Key) : data.find(x => x.ParticipantKey === item.Key);
                                    if (this.scoreCard.HierarchyType === this.hierarchyType.Custom && child) {
                                        item.Status = true;
                                    } else {
                                        if (this.scoreCard.HierarchyType === this.hierarchyType.Standard && child) {
                                            item.Status = true;
                                        }
                                    }
                                }
                            }
                            this.setViewTreeData(selectedParticipant, 'ParticipantKey');
                        }
                    });
                    break;
            }
        }
    }

    // public getWhoCanViewSaveData() {
    //     if (this.scoreCard.ScoreCardVisibilityMaps.length > 0) {

    //     }
    //     else {
    //         this.scoreCard.ScoreCardVisibilityMaps = this.selectedStdHeirarcy;
    //     }
    // }

    ////-----------------Standard Heirarcy End---------------------//////

    private checkScoreCardName() {
        this.globalInfoDataService.checkScoreCardName(this.scoreCard.Id, this.scoreCard.Name).then(data => {
            if (!data) {
                this.globalInfoDataService.save(this.scoreCard).then(scoreCardId => {
                    if (scoreCardId > 0) {
                        this.isRequired = false;
                        this.commonEventsService.getEvent('next').next();
                    }
                });
            } else {
                this.scoreCardNameExists = data;
            }
        });
    }

    private save() {
        this.isRequired = true;
        if (this.scoreCard.Name !== undefined && this.scoreCard.Name !== '' && this.scoreCard.Level !== undefined && this.scoreCard.ParticipantType !== undefined
            && this.scoreCard.TimeFrames.length > 0 && this.scoreCard.DefaultTimeFrameId !== undefined) {
            this.checkScoreCardName();
        }
    }

    private loadTimeFrames(tfGtroups: Map<number, Array<TimeFrame>>): void {
        if (tfGtroups) {
            this.timeFrameGroups = new Array();
            tfGtroups.forEach((tfg, key) => {
                this.timeFrameGroups.push(tfg);
            });
        }
    }
}

export const GlobalInfo: angular.IComponentOptions = {
    template: require('./globalInfo.html'),
    controller: GlobalInfoController
};
