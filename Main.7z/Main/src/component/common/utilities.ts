export function HasKey<K, T>(key: K, map: Map<K, T>): boolean {
    let found = false;
    for (let k in map) {
        if(key != undefined && k === key.toString()){
            found = true;
        }
    }
    return found;
}


 