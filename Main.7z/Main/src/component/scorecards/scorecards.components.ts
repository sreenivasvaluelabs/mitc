import { INavigationStageService, NavigationStageService, Stage } from '../service/navigation-stage-service';

import { IScoreCardDataService, ScoreCardDataService } from '../service/scorecard-data-service';
import { ScoreCardModel, ScoreCard } from '../model/scorecard-model';

export class ScorecardsController {

  public scoreCardModel: ScoreCardModel = new ScoreCardModel();

  constructor(private $state: ng.ui.IStateService,
    private navigationStageService: INavigationStageService,
    private scorecardDataService: IScoreCardDataService) {

    this.scorecardDataService.getScoreCards().then(data => {
      debugger;
      if (<Array<ScoreCard>>data) {
        this.scoreCardModel.gridScoreCard = <Array<ScoreCard>>data;
      }
    });
  }

  public createScoreCard() {
    this.scorecardDataService.reset();
    this.navigationStageService.setStage(Stage.GlobalInfo, this.$state);
  }

  public onRowClick(scorecardId: number) {
    this.scorecardDataService.setCurrentScoreCardId(scorecardId);
    this.navigationStageService.setStage(Stage.ReviewAndEdit, this.$state);
  }
}

export const Scorecards: angular.IComponentOptions = {
  template: require('./scorecards.html'),
  controller: ScorecardsController
};
