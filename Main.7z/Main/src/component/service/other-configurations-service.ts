import { EmailSubscription } from '../model/email-subscription.model';
import { Participant } from '../model/participant-model';
import { OtherConfigModel } from '../model/other-configurations-model';
import { DataFilter } from '../model/data-filter-model';
import * as stream from 'stream';
import { ScoreCardDataService, IScoreCardDataService } from './scorecard-data-service';
import * as constants from 'constants';
import { arrayify } from 'tslint/lib/utils';
import { GlobalInfoModel } from '../model/global-info-model';
import { HierarchyType, ParticipantType, ScoreCardLevel } from '.././common/enums';
import { IApiDataService, ApiDataService } from './api-data-service';
import { Constants, IConstants } from '../common/Constants';
import { ICommonService, CommonService } from './common-service';
import { isNullOrUndefined } from 'util';
import { DataFilterMap } from '../model/data-filter-map-model';
import { DataFiilterVM } from '../model/data-filter-view-model';

export interface IOtherConfigDataService {
    getScoreCardDataFilterData(scoreCardId: number);
    getAllDataFilters();
    saveDataFiltersData(dataFiltesrViewModel: DataFiilterVM, emailSubscriptionData: Array<EmailSubscription>);
    getParticipantsData(scoreCardId: number);
    getWhoCanViewTree();
};

export class OtherConfigDataService implements IOtherConfigDataService {

    constructor(private apiDataService: IApiDataService, private constants: IConstants,
        private scorecardDataService: IScoreCardDataService,
        private commonService: ICommonService, private $q: ng.IQService) {
    }

    public getScoreCardDataFilterData(scoreCardId: number): ng.IPromise<any> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'datafilters/' + scoreCardId)
            .then(data => {
                if (data) {
                    let dataFilterMappedList = new Array<DataFilterMap>();
                    for (let mdf of <Array<any>>data) {
                        let newDataFilter = new DataFilter();
                        if (mdf.DataFilter) {
                            newDataFilter = {
                                Id: mdf.DataFilter['Id'],
                                FilterName: mdf.DataFilter['FilterName'],
                                PossibleValues: mdf.DataFilter['PossibleValues'].split(','),
                                ValueType: mdf.DataFilter['ValueType']
                            };
                        }
                        dataFilterMappedList.push({
                            Id: mdf['Id'],
                            Values: mdf['Values'].split(','),
                            ScoreCardId: mdf['ScoreCardId'] || scoreCardId,
                            DataFilterId: mdf['DataFilterId'],
                            DataFilter: newDataFilter
                        });
                    }
                    return dataFilterMappedList;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }

    public getAllDataFilters(): ng.IPromise<any> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'datafilters')
            .then(data => {
                if (data) {
                    let dataFiltersList = new Array<DataFilter>();
                    for (let df of <Array<any>>data) {
                        dataFiltersList.push({
                            Id: df['Id'],
                            FilterName: df['FilterName'],
                            PossibleValues: df['PossibleValues'].split(','),
                            ValueType: df['ValueType']
                        });
                    }
                    return dataFiltersList;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    };

    public saveDataFiltersData(dataFiltesrViewModel: DataFiilterVM, emailSubscriptionData: Array<EmailSubscription>): ng.IPromise<any> {
        console.log(dataFiltesrViewModel);
        // let scoreCardIds = this.scorecardDataService.getCurrentScoreCardId();
        let scoreCardId = this.scorecardDataService.getCurrentScoreCardId();
        dataFiltesrViewModel.DataFiltersMappedList.map(obj => {
            obj.ScoreCardId = scoreCardId;
        });
        return this.apiDataService
            .postData(this.constants.BaseUrl + 'datafilters', dataFiltesrViewModel)
            .then((data) => {
                if (!isNullOrUndefined(emailSubscriptionData) && emailSubscriptionData.length > 0) {
                    return this.apiDataService
                        .postData(this.constants.BaseUrl + 'emailpreferences?scoreCardId=' + scoreCardId, emailSubscriptionData)
                        .then(res => {
                            console.log(res);
                            return true;
                        })
                        .catch((error) => {
                            console.log(error);
                            return false;
                        });
                } else {
                    return true;
                }
            })
            .catch((error) => {
                console.log(error);
                return false;
            });
    };

    public getParticipantsData(scoreCardId: number): ng.IPromise<any> {
        return this.apiDataService.getData(this.constants.BaseUrl + 'emailpreferences?scoreCardId=' + scoreCardId)
            .then((data) => {
                let emailSubscriptionsList = new Array<EmailSubscription>();
                debugger;
                for (let reg of <Array<any>>data) {
                    emailSubscriptionsList.push({
                        Participant: reg['Participant'],
                        Schedules: reg['Schedules']
                    });
                }
                return emailSubscriptionsList;
            })
            .catch((err) => {
                console.log(err);
            });
    };

    public getWhoCanViewTree(): ng.IPromise<void | Array<Participant>> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'hierarchy/whoCanViewTree')
            .then(data => {
                if (data) {
                    let whocanView: Participant[] = new Array<Participant>();
                    for (let reg of <Array<any>>data) {
                        whocanView.push({
                            Key: reg['Key'],
                            Code: reg['Code'],
                            Level: reg['Level'],
                            Name: reg['Name'],
                            Status: false,
                            Children: reg['Children']
                        });
                    }
                    return whocanView;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }
}
