import { ScoreCardDataService, IScoreCardDataService } from './scorecard-data-service';
import * as constants from 'constants';
import { IApiDataService, ApiDataService } from './api-data-service';
import { MetricsDataModel, Metric, ScoreCardMetricMap, Anchor } from '../model/metrics-data-model';
import { Constants } from '../common/Constants';
import { Array } from 'es6-shim';
import { SubjectArea } from "../common/enums";

export interface IMetricsDataService {
    getAllMetrics(): ng.IPromise<void | Array<Metric>>;
    getAllAnchors(): ng.IPromise<void | Array<Anchor>>;
    getScoreCardMetricData(scoreCardId: string): ng.IPromise<any>;
    save(selectedMetrics: Array<ScoreCardMetricMap>): ng.IPromise<any>;
}
export class MetricsDataService implements IMetricsDataService {
    private metrics: Array<Metric>;
    constructor(private apiDataService: IApiDataService, private constants: Constants,
        private scorecardDataService: IScoreCardDataService, private $q: ng.IQService) {
        this.metrics = new Array();

    }
    public getAllMetrics(): ng.IPromise<void | Array<Metric>> {
        let deffered = this.$q.defer<Array<Metric>>();
        if (this.metrics.length > 0) {
            deffered.resolve(this.metrics);
        } else {
            this.apiDataService
                .getData(this.constants.BaseUrl + 'metrics')
                .then(data => {
                    if (data) {
                        for (let metric of <Array<any>>data) {
                            this.metrics.push({
                                Id: parseInt(metric['Id']),
                                Name: metric['Name'],
                                SubjectArea: metric['SubjectArea'],
                                MitchellRecommended: metric['MitchellRecommended'],
                                IsHeigherBetter: metric['IsHeigherBetter'],
                            });
                        }
                        deffered.resolve(this.metrics);
                    }
                    deffered.resolve(null);
                }).catch(error => {
                    deffered.reject(error);
                });
        }
        return deffered.promise;
    }

    public getAllAnchors(): ng.IPromise<void | Array<Anchor>> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'anchor')
            .then(data => {
                if (data) {
                    let anchors = new Array<Anchor>();
                    for (let anchor of <Array<any>>data) {
                        anchors.push({
                            Id: anchor['Id'],
                            Name: anchor['Name'],
                            SubjectArea: anchor['SubjectArea'],
                            Type: anchor['Type'],
                            Default: anchor['Default']
                        });
                    }
                    return anchors;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }

    public getScoreCardMetricData(scoreCardId: string): ng.IPromise<any> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'metrics/' + scoreCardId)
            .then(data => {
                console.log(data);
                return data;
            }).catch(error => {
                console.log(error);
            });
    }

    public save(selectedMetrics: Array<ScoreCardMetricMap>): ng.IPromise<any> {
        let url = this.constants.BaseUrl + 'metrics?scoreCardId=' + this.scorecardDataService.getCurrentScoreCardId();
        return this.apiDataService
            .postData(url, selectedMetrics)
            .then((data) => {
                return data;
            })
            .catch((error) => console.log(error));
    }

}

