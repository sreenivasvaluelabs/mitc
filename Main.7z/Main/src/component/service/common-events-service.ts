import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subject } from 'rxjs/Subject';


export interface ICommonEventsService {
    getEvent(name: string): Subject<string>;

}

export class CommonEventsService implements ICommonEventsService {

    private topNavigationEvent: BehaviorSubject<string>;
    private saveEvent: Subject<string>;
    private nextEvent: Subject<string>;
    private deleteEvent: Subject<string>;

    constructor(private $http: ng.IHttpService) {
        this.topNavigationEvent = new BehaviorSubject<string>('global');
        this.saveEvent = new Subject<string>();
        this.nextEvent = new Subject<string>();
        this.deleteEvent = new Subject<string>();

    }

    getEvent(name: string): Subject<string> {
        console.log('common serve' + name);
        switch (name) {
            case 'save':
                return this.saveEvent;
            case 'next':
                return this.nextEvent;
            case 'delete':
                return this.deleteEvent;
        }
    }

}