import { IDisabledInterval } from 'tslint/lib';
import { IApiDataService, ApiDataService } from './api-data-service';
import { Constants } from '../common/Constants';
import { createScoreCard, ScoreCard } from '../model/scorecard-model';
import { HierarchyType, ScoreCardLevel, ParticipantType } from '../common/enums';
import { Array } from 'es6-shim';
import { stringify } from 'angular-ui-router/release/ng1';


export interface IScoreCardDataService {
    getScoreCards(): ng.IPromise<void | Array<ScoreCard>>;
    getScoreCard(id: number): ng.IPromise<void | ScoreCard>;
    getCurrentScoreCardId(): number;
    setCurrentScoreCardId(scoreCardId: number);
    setCurrentScoreCard(data: ScoreCard);
    getCurrentScoreCard();
    setIsCloningOrCopying(copiedScoreCardId: number);
    getIsCloningOrCopying(): boolean;
    setIsEdit(scoreCardId: number);
    reset();
}

export class ScoreCardDataService implements IScoreCardDataService {
    private currentScoreCardId: number;
    private copiedScoreCardId: number;
    private currentScoreCard: ScoreCard;
    private isCopyOrClone: boolean;
    private isEdit: boolean;
    constructor(private apiDataService: IApiDataService,
        private constants: Constants, private $http: ng.IHttpService,
        private $q: ng.IQService) {
    }

    public getEmailFrqquencyValue(scorecard: ScoreCard): string {
        debugger;
        let freuencyName: string = '';
        if (scorecard['EmailSubscriptions'] && scorecard['EmailSubscriptions'].length > 0) {
            freuencyName = scorecard['EmailSubscriptions'][0].Daily ? 'Daily' : freuencyName;
            freuencyName = scorecard['EmailSubscriptions'][0].Weekly ? 'Weekly' : freuencyName;
            freuencyName = scorecard['EmailSubscriptions'][0].Monthly ? 'Monthly' : freuencyName;
            freuencyName = scorecard['EmailSubscriptions'][0].Quarterly ? 'Quarterly' : freuencyName;
        }
        return freuencyName;
    }

    public getScoreCards(): ng.IPromise<void | Array<ScoreCard>> {
        return this.apiDataService
            .getData<Array<any>>(this.constants.BaseUrl + 'scorecards')
            .then(scoreCards => {
                if (scoreCards) {
                    let scList = new Array<ScoreCard>();
                    for (let sc of scoreCards) {
                        scList.push(createScoreCard(
                            sc['Id'],
                            sc['Name'],
                            sc['Description'],
                            sc['CompanyCode'],
                            sc['Created'],
                            sc['Updated'],
                            sc['CreatedBy'],
                            sc['ModifiedBy']
                        ));
                    }
                    return scList;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }

    public getScoreCard(id: number): ng.IPromise<void | ScoreCard> {
        return this.apiDataService
            .getData<any>(this.constants.BaseUrl + 'scorecards/' + id)
            .then(scoreCard => {
                if (scoreCard) {
                    this.currentScoreCard = createScoreCard(
                        scoreCard['Id'],
                        scoreCard['Name'],
                        scoreCard['Description'],
                        scoreCard['CompanyCode'],
                        scoreCard['Created'],
                        scoreCard['CreatedBy'],
                        scoreCard['Updated'],
                        scoreCard['ModifiedBy']
                    );
                    this.currentScoreCard.CanAllView = scoreCard['CanAllView'];
                    this.currentScoreCard.DefaultTimeFrameId = scoreCard['DefaultTimeFrameId'];
                    this.currentScoreCard.DisplayKPIWeights = scoreCard['DisplayKPIWeights'];
                    this.currentScoreCard.DisplayPeerPerformance = scoreCard['DisplayPeerPerformance'];
                    this.currentScoreCard.HierarchyType = scoreCard['HierarchyType'];
                    this.currentScoreCard.Level = scoreCard['Level'];
                    this.currentScoreCard.MaskPeerNames = scoreCard['MaskPeerNames'];
                    this.currentScoreCard.ParticipantType = scoreCard['ParticipantType'];
                    this.currentScoreCard.SendEmail = scoreCard['SendEmail'];
                    this.currentScoreCard.TimeFrames = new Array();
                    this.currentScoreCard.EmailFrequencyValue = this.getEmailFrqquencyValue(scoreCard);
                    let selectedTimeFrames = scoreCard['TimeFrames'];
                    for (let tf of selectedTimeFrames) {
                        this.currentScoreCard.TimeFrames.push({
                            Id: tf['Id'],
                            Name: tf['Name'],
                            Description: tf['Description']
                        });
                    }

                    this.currentScoreCard.Hierarchy = new Array();
                    let selectedHeirarchy = scoreCard['Hierarchy'];
                    for (let hrcy of selectedHeirarchy) {
                        this.currentScoreCard.Hierarchy.push({
                            GroupName: hrcy['GroupName'],
                            RegionKey: hrcy['RegionKey'],
                            DivisionKey: hrcy['DivisionKey'],
                            OfficeKey: hrcy['OfficeKey'],
                            ParticipantKey: hrcy['ParticipantKey']
                        });
                    }

                    this.currentScoreCard.ScoreCardVisibilityMaps = new Array();
                    let selectedViewers = scoreCard['ScoreCardVisibilityMaps'];
                    for (let view of selectedViewers) {
                        this.currentScoreCard.ScoreCardVisibilityMaps.push({
                            RegionKey: view['RegionKey'],
                            DivisionKey: view['DivisionKey'],
                            OfficeKey: view['OfficeKey'],
                            ParticipantKey: view['ParticipantKey']
                        });
                    }

                    this.currentScoreCard.Metrics = new Array();
                    this.currentScoreCard.Metric = new Array();
                    let selectedMetricMaps = scoreCard['Metrics'];
                    for (let mm of selectedMetricMaps) {
                        if (mm.Metric) {
                            this.currentScoreCard.Metrics.push({
                                MetricId: mm['Metric']['Id'],
                                MetricName: mm['Metric']['Name'],
                                SubArea: mm['Metric']['SubjectArea'],
                                ScoreThisMetric: mm['ScoreThisMetric'],
                                Target: mm['Target'],
                                Weight: mm['Wieght'],
                                OwnershipAnchorId: mm['OwnerShipAnchor'] == undefined ? '' : mm['OwnerShipAnchor'].Id,
                                HierarchyAnchorId: mm['HeirarchyAnchor'] == undefined ? '' : mm['HeirarchyAnchor'].Id,
                                DateAnchorId: mm['DateAnchor'] == undefined ? '' : mm['DateAnchor'].Id,
                                OwnershipAnchor: mm['OwnerShipAnchor'],
                                HierarchyAnchor: mm['HeirarchyAnchor'],
                                DateAnchor: mm['DateAnchor']
                            });
                            this.currentScoreCard.Metric.push({
                                Id: mm['Metric']['Id'],
                                Name: mm['Metric']['Name'],
                                SubjectArea: mm['Metric']['SubjectArea'],
                                IsHeigherBetter: mm['Metric']['IsHeigherBetter'],
                                MitchellRecommended: mm['Metric']['MitchellRecommended']
                            });
                        }

                    }

                    this.currentScoreCard.DataFilters = new Array();
                    let selectedDataFilters = scoreCard['DataFilters'];
                    selectedDataFilters.forEach(df => {
                        this.currentScoreCard.DataFilters.push(df);
                    });

                    return this.currentScoreCard;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }

    public getCurrentScoreCardId(): number {
        return this.currentScoreCardId;
    }

    public setCurrentScoreCardId(scoreCardId: number) {
        this.currentScoreCardId = scoreCardId;
    }

    public setCurrentScoreCard(data: ScoreCard) {
        this.currentScoreCard = data;
    }

    public getCurrentScoreCard() {
        return this.currentScoreCard;
    }

    public setIsCloningOrCopying(copiedScoreCardId: number) {
        this.isEdit = false;
        this.isCopyOrClone = true;
        this.copiedScoreCardId = copiedScoreCardId;
    }

    public getIsCloningOrCopying(): boolean {
        return this.isCopyOrClone;
    }

    public setIsEdit(scoreCardId: number) {
        this.isEdit = true;
        this.isCopyOrClone = false;
        this.currentScoreCardId = scoreCardId;
    }

    public reset() {
        this.isEdit = false;
        this.isCopyOrClone = false;
        this.currentScoreCardId = null;
        this.copiedScoreCardId = null;
        this.currentScoreCard = null;
    }

    // tslint:disable-next-line:eofline
}

