export type ModalDialogConfig = {
    templateUrl: string;
    controller: any;
    controllerAs: string;
    locals: any;
    clickOutsideToClose: boolean;
};

export interface IModalDialog {
    OpenDialog(config: ModalDialogConfig);
    closeDialog<T>(data: T);
    discardDialog();
}

export class ModalDialog implements ModalDialog {
    constructor(private $mdDialog: ng.material.IDialogService) {
    }

    public OpenDialog(config: ModalDialogConfig) {
        return this.$mdDialog.show({
            template: config.templateUrl,
            controller: config.controller,
            controllerAs: config.controllerAs,
            locals: config.locals,
            clickOutsideToClose: config.clickOutsideToClose,
        });
    }

    public closeDialog<T>(data: T) {
        return this.$mdDialog.hide(data);
    }

    public discardDialog() {
        return this.$mdDialog.hide();
    }
}
