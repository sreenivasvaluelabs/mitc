import { BaseContoller } from '../common/base-controller';
import { ICommonEventsService, CommonEventsService } from '../service/common-events-service';
import { INavigationStageService, NavigationStageService, Stage } from '../service/navigation-stage-service';
import { AppController } from '../../app/main/app';

export class TopNavigationController extends BaseContoller {

  constructor(private $state: ng.ui.IStateService,
    private navigationStageService: INavigationStageService,
    private commonEventsService: ICommonEventsService) {
    super();
    this.commonEventsService.getEvent('next').takeUntil(this.$destroy).subscribe(() => {
      this.changeRoute();
    });
  }

  public isReviewEditPage() {
    var currentPage = this.navigationStageService.getStage();
    if (currentPage === 3) {
      return true;
    } else {
      return false;
    }
  }

  public isCurrentStage(name: string) {
    return this.navigationStageService.isCurrentStage(name);
  }

  public done() {
    this.$state.go('app');
  }

  public delete() {
    this.commonEventsService.getEvent('delete').next('');
    this.done();
  }

  public saveAndNext() {
    this.commonEventsService.getEvent('save').next();
  }

  public previous() {
    this.previousState();
  }

  public previousState() {
    switch (this.navigationStageService.getStage()) {
      case Stage.Metrics:
        this.navigationStageService.setStage(Stage.GlobalInfo, this.$state);
        break;
      case Stage.OtherConfiguration:
        this.navigationStageService.setStage(Stage.Metrics, this.$state);
        break;
    }
  }

  private changeRoute() {
    switch (this.navigationStageService.getStage()) {
      case Stage.GlobalInfo:
        this.navigationStageService.setStage(Stage.Metrics, this.$state);
        break;
      case Stage.Metrics:
        this.navigationStageService.setStage(Stage.OtherConfiguration, this.$state);
        break;
      case Stage.OtherConfiguration:
        this.navigationStageService.setStage(Stage.ReviewAndEdit, this.$state);
        break;
      default:
        this.navigationStageService.setStage(Stage.GlobalInfo, this.$state);
        break;
    }
  }

}

export const TopNavigation: angular.IComponentOptions = {
  template: require('./top-navigation.html'),
  controller: TopNavigationController
};
