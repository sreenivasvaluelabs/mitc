export class DataFilter {
    public Id: string;
    public FilterName: string;
    public PossibleValues: Array<string>;
    public ValueType: string;
}