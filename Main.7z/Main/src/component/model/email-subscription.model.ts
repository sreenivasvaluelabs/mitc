import { EmailFrequency } from '../common/enums';
import { Participant } from './participant-model';
export class EmailSubscription {
    Participant: Participant;
    Schedules: Array<number>;
}
