import { Participant } from './participant-model';
import { HierarchyType, ScoreCardLevel, ParticipantType } from '../common/enums';
import { TimeFrame } from './time-frame-model';
import { ScoreCardMetricMap, Metric } from './metrics-data-model';
import { DataFilterMap } from './data-filter-map-model';
import { Hierarchy } from '../model/global-info-model';


export class ScoreCardModel {
    public gridScoreCard: Array<ScoreCard> = new Array();
    Metric: any = new Array();

    // tslint:disable-next-line:eofline
}

export class ScoreCard {
    public Id: number = -1;
    public Name: string;
    public Description: string;
    public HierarchyType: HierarchyType;
    public Level: ScoreCardLevel;
    public CompanyCode: string = 'Mitchell';
    public CanAllView: boolean = true;
    public DisplayPeerPerformance: boolean = true;
    public MaskPeerNames: boolean;
    public DisplayKPIWeights: boolean;
    public SendEmail: boolean;
    public ParticipantType: ParticipantType;
    public DefaultTimeFrameId: string = '';
    public Created: Date;
    public Modified: Date;
    public CreatedBy: string;
    public ModifiedBy: string;
    public TimeFrames: Array<TimeFrame> = new Array();
    public Metrics: Array<ScoreCardMetricMap>;
    public Metric: Array<Metric>;
    public DataFilters: Array<DataFilterMap>;
    public EmailFrequencyValue: string;
    public Hierarchy: Array<Hierarchy> = new Array();
    public ScoreCardVisibilityMaps: Array<Hierarchy> = new Array();
}

export function createScoreCard(Id: number, name: string, description: string, companyCode: string, created: Date, modified: Date, createdBy: string, modifiedBy: string): ScoreCard {
    let scoreCard = new ScoreCard();
    scoreCard.Id = Id;
    scoreCard.Name = name;
    scoreCard.Description = description;
    scoreCard.CompanyCode = companyCode;
    scoreCard.Created = created;
    scoreCard.CreatedBy = createdBy;
    scoreCard.Modified = modified;
    scoreCard.ModifiedBy = modifiedBy;
    return scoreCard;
}


