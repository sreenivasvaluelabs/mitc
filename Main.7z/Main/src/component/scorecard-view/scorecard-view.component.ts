
export class ScoreCardViewInfoController {

    constructor(private $state: ng.ui.IStateService) {

    }
    public RegionView() {
        this.$state.go('regionview');
    }

}

export const ScoreCardView: angular.IComponentOptions = {
    template: require('./scorecard-view.html'),
    controller: ScoreCardViewInfoController
};
