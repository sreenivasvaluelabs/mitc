import { browser, element, by, By, $, $$, protractor, ExpectedConditions } from 'protractor';
import { PageUtilities } from '../base.po';
import { TestPage } from '../po/testpage.po';
import { ComponentPage } from '../po/component.po';

/*global Promise*/
/*eslint-disable max-statements, max-len, indent*/

describe('Component tests:', function () {
    var testPage = new TestPage();
    var componentPage = new ComponentPage();

    beforeEach(function () {
        browser.get('/index.html');
    });

    describe('Component behaviors:', function () {
        it('should make everyone laugh with Jason\'s favorite joke', function () {
            // testPage.navBarButton().click();
            // testPage.yesdogComponentButton().click();
            // PageUtilities.waitForElementToBeDisplayed(componentPage.yesDogComponent());
            // expect<any>(componentPage.yesDogComponent().isDisplayed()).toBe(true);
            expect(true).toBe(true);
        });

        // it('should allow the user to see a cute dog', function () {
        //     testPage.navBarButton().click();
        //     testPage.yesdogComponentButton().click();
        //     PageUtilities.waitForElementToBeDisplayed(componentPage.yesDogComponent());
        //     expect<any>(componentPage.yesDogPupElement(1).isDisplayed()).toBe(true);
        // });

        // it('should allow the user to see an even cuter dog', function () {
        //     testPage.navBarButton().click();
        //     testPage.yesdogComponentButton().click();
        //     PageUtilities.waitForElementToBeDisplayed(componentPage.yesDogComponent());
        //     componentPage.yesDogToggle().click();
        //     expect<any>(componentPage.yesDogPupElement(2).isDisplayed()).toBe(true);
        // });
    });
});

/*eslint-enable max-statements, max-len, indent*/
