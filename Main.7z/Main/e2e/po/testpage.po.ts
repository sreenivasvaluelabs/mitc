import { browser, element, by, By, $, $$, protractor, ElementFinder } from 'protractor';

export class TestPage {
    public navBarButton(): ElementFinder {
        return element(By.id('mi-module-test-page__nav__trigger'));
    }

    public navBar(): ElementFinder {
        return element(By.id('mi-module-test-page__nav'));
    }

    public yesdogComponentButton(): ElementFinder {
        return element(By.id('mi-module-test-page__component__load-button'));
    }
}
