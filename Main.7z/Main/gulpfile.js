const gulp = require('gulp');
const HubRegistry = require('gulp-hub');
const browserSync = require('browser-sync');

const conf = require('./conf/gulp.conf');

// Load some files into the registry
const hub = new HubRegistry([conf.path.tasks('*.js')]);

// Tell gulp to use the tasks just loaded
gulp.registry(hub);

gulp.task('build', gulp.series('clean', 'z-build-step:translate:copy-po-files', 'z-build-step:copy-npm-dependencies', gulp.parallel('z-build-step:webpack:dist')));
gulp.task('test', gulp.series('z-build-step:karma:single-run'));
gulp.task('test:auto', gulp.series('z-build-step:karma:auto-run'));
gulp.task('serve', gulp.series('clean', 'z-build-step:webpack:watch', 'z-build-step:watch', 'z-build-step:browsersync'));
gulp.task('serve:dist', gulp.series('clean', 'z-build-step:webpack:dist-app', 'z-build-step:browsersync:dist'));
gulp.task('default', gulp.series('clean', 'build'));
gulp.task('protractor', gulp.series('z-build-step:webpack:dev', 'z-build-step:browsersync', 'z-build-step:webdriver-update', 'z-build-step:protractor'));
gulp.task('protractor:dist', gulp.series('z-build-step:webpack:dist-app', 'z-build-step:browsersync:dist', 'z-build-step:webdriver-update', 'z-build-step:protractor'));

gulp.task('z-build-step:watch', watch);

function reloadBrowserSync(cb) {
    browserSync.reload();
    cb();
}

function watch(done) {
    gulp.watch(conf.path.tmp('index.html'), reloadBrowserSync);
    done();
}
